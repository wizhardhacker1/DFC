@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Family Calendar Hub Installer
echo ==================================================
echo  Family Calendar Hub v19 - Windows Installer
echo ==================================================
where python >nul 2>nul || (echo Python 3.11+ is required.& pause& exit /b 1)
set "INSTALL_AI=N"
echo.
set /p "INSTALL_AI=Install optional Local AI (Ollama + llama3.2:3b)? [y/N]: "
if /I "!INSTALL_AI!"=="Y" (
 where ollama >nul 2>nul
 if errorlevel 1 (
  echo [AI] Ollama not detected. Installing optional Local AI...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://ollama.com/install.ps1 | iex"
  if errorlevel 1 (echo ERROR: Optional Ollama installation failed.& pause& exit /b 1)
  set "PATH=%LOCALAPPDATA%\Programs\Ollama;%PATH%"
 )
 start "Ollama" /min ollama serve >nul 2>&1
 timeout /t 3 /nobreak >nul
 ollama list | findstr /I /C:"llama3.2:3b" >nul
 if errorlevel 1 (
  echo [AI] Installing optional llama3.2:3b model...
  ollama pull llama3.2:3b || (echo ERROR: Optional model installation failed.& pause& exit /b 1)
 )
 if not exist "%LOCALAPPDATA%\FamilyCalendarHub" mkdir "%LOCALAPPDATA%\FamilyCalendarHub"
 type nul > "%LOCALAPPDATA%\FamilyCalendarHub\local_ai_enabled.flag"
 echo [AI] Optional Local AI installed/enabled.
) else (
 if exist "%LOCALAPPDATA%\FamilyCalendarHub\local_ai_enabled.flag" del /q "%LOCALAPPDATA%\FamilyCalendarHub\local_ai_enabled.flag"
 echo [AI] Skipped. Ollama will NOT be installed, started, or enabled by Family Calendar Hub.
)
if not exist .venv python -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
echo [Voice 1/5] Verifying Microsoft Visual C++ runtime required by ONNX Runtime...
python -c "import onnxruntime; print('ONNX Runtime', onnxruntime.__version__, 'native DLL test passed')" >nul 2>&1
if errorlevel 1 (
  echo [Voice] ONNX native DLL test failed. Installing/repairing Microsoft Visual C++ x64 Runtime...
  set "VCREDIST=%TEMP%\fch_vc_redist.x64.exe"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing 'https://aka.ms/vc14/vc_redist.x64.exe' -OutFile $env:VCREDIST"
  if errorlevel 1 (echo ERROR: Could not download the official Microsoft Visual C++ x64 Runtime.& pause& exit /b 1)
  if not exist "!VCREDIST!" (echo ERROR: Microsoft Visual C++ Runtime download did not create the installer file.& pause& exit /b 1)
  for %%A in ("!VCREDIST!") do if %%~zA LSS 1000000 (echo ERROR: Microsoft Visual C++ Runtime download is incomplete.& del /q "!VCREDIST!" ^>nul 2^>^&1& pause& exit /b 1)
  "!VCREDIST!" /install /passive /norestart
  set "VCEXIT=!ERRORLEVEL!"
  if not "!VCEXIT!"=="0" if not "!VCEXIT!"=="1638" if not "!VCEXIT!"=="3010" (echo ERROR: Microsoft Visual C++ Runtime installer returned !VCEXIT!.& pause& exit /b 1)
  del "!VCREDIST!" >nul 2>&1
  echo [Voice] Re-testing ONNX native DLL loading...
  python -c "import onnxruntime; print('ONNX Runtime', onnxruntime.__version__, 'native DLL test passed')"
  if errorlevel 1 (
    echo [Voice] ONNX still cannot load. Reinstalling the CPU runtime wheel...
    python -m pip uninstall -y onnxruntime >nul 2>&1
    python -m pip install --no-cache-dir --force-reinstall "onnxruntime>=1.20,<2"
    python -c "import onnxruntime; print('ONNX Runtime', onnxruntime.__version__, 'native DLL test passed')"
    if errorlevel 1 (echo ERROR: ONNX Runtime native DLLs still cannot load after VC++ repair. A Windows restart may be required; restart Windows, then run this installer again.& pause& exit /b 1)
  )
)
echo [OK] ONNX Runtime native DLL test passed.
echo [Voice 2/5] Installing Piper neural TTS...
set "VOICE_DIR=%LOCALAPPDATA%\FamilyCalendarHub\voices"
if not exist "%VOICE_DIR%" mkdir "%VOICE_DIR%"
python -m pip install --upgrade "piper-tts>=1.3.0" || (echo ERROR: Piper neural voice engine installation failed.& pause& exit /b 1)
echo [Voice 3/5] Verifying Piper can import...
python -c "from piper import PiperVoice; print('Piper import passed')" || (echo ERROR: Piper cannot load even though it is installed. Check the ONNX/VC++ messages above.& pause& exit /b 1)
echo [Voice 4/5] Installing/verifying Lessac neural voice...
set "VOICE_MODEL=%VOICE_DIR%\en_US-lessac-medium.onnx"
set "VOICE_CONFIG=%VOICE_DIR%\en_US-lessac-medium.onnx.json"
if not exist "%VOICE_MODEL%" (
  echo [Voice] Downloading neural model with Windows curl...
  curl.exe --fail --location --retry 3 --connect-timeout 20 --output "%VOICE_MODEL%.part" "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/lessac/medium/en_US-lessac-medium.onnx"
  if errorlevel 1 (del /q "%VOICE_MODEL%.part" ^>nul 2^>^&1& echo ERROR: Neural voice model download failed using Windows TLS. Check firewall/proxy access to huggingface.co.& pause& exit /b 1)
  move /Y "%VOICE_MODEL%.part" "%VOICE_MODEL%" >nul
)
if not exist "%VOICE_CONFIG%" (
  echo [Voice] Downloading neural voice configuration with Windows curl...
  curl.exe --fail --location --retry 3 --connect-timeout 20 --output "%VOICE_CONFIG%.part" "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/lessac/medium/en_US-lessac-medium.onnx.json"
  if errorlevel 1 (del /q "%VOICE_CONFIG%.part" ^>nul 2^>^&1& echo ERROR: Neural voice configuration download failed using Windows TLS. Check firewall/proxy access to huggingface.co.& pause& exit /b 1)
  move /Y "%VOICE_CONFIG%.part" "%VOICE_CONFIG%" >nul
)
for %%A in ("%VOICE_MODEL%") do if %%~zA LSS 1000000 (echo ERROR: Neural voice model file is incomplete.& del /q "%VOICE_MODEL%" ^>nul 2^>^&1& pause& exit /b 1)
for %%A in ("%VOICE_CONFIG%") do if %%~zA LSS 1000 (echo ERROR: Neural voice configuration file is incomplete.& del /q "%VOICE_CONFIG%" ^>nul 2^>^&1& pause& exit /b 1)
echo [Voice 5/5] Generating a real WAV test...
python -c "import os,wave; from piper import PiperVoice; p=r'%VOICE_DIR%\en_US-lessac-medium.onnx'; assert os.path.exists(p) and os.path.exists(p+'.json'); v=PiperVoice.load(p); w=wave.open(r'%TEMP%\fch_voice_test.wav','wb'); v.synthesize_wav('Family Calendar Hub voice test.',w); w.close(); assert os.path.getsize(r'%TEMP%\fch_voice_test.wav')>1000" || (echo ERROR: Piper loaded but could not synthesize neural audio.& pause& exit /b 1)
del "%TEMP%\fch_voice_test.wav" >nul 2>&1
echo [OK] Neural voice engine, ONNX Runtime, and Lessac voice verified end-to-end.
mkdir "%LOCALAPPDATA%\FamilyCalendarHub\data" 2>nul
mkdir "%LOCALAPPDATA%\FamilyCalendarHub\backups" 2>nul
mkdir "%LOCALAPPDATA%\FamilyCalendarHub\logs" 2>nul

echo.
echo Startup mode:
echo   [1] Start automatically when this user logs in (recommended for wall display)
echo   [2] Start automatically at system boot
 echo  [3] Manual startup only
choice /C 123 /N /M "Choose 1, 2, or 3: "
set MODE=%ERRORLEVEL%
schtasks /Delete /TN "Family Calendar Hub" /F >nul 2>&1
if "%MODE%"=="1" schtasks /Create /TN "Family Calendar Hub" /SC ONLOGON /TR "\"%~dp0start_calendar.cmd\"" /RL LIMITED /F >nul
if "%MODE%"=="2" (
 schtasks /Create /TN "Family Calendar Hub" /SC ONSTART /TR "\"%~dp0start_calendar.cmd\"" /RU SYSTEM /RL HIGHEST /F >nul 2>&1
 if errorlevel 1 echo NOTE: Boot startup requires Administrator rights. Re-run installer as Administrator or choose login startup.
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws=New-Object -ComObject WScript.Shell;$d=[Environment]::GetFolderPath('Desktop');$s=$ws.CreateShortcut((Join-Path $d 'Family Calendar Hub.lnk'));$s.TargetPath='%~dp0start_calendar.cmd';$s.WorkingDirectory='%~dp0';$s.IconLocation='%~dp0assets\family_calendar_hub.ico';$s.Save();$r=$ws.CreateShortcut((Join-Path $d 'Restart Family Calendar Hub.lnk'));$r.TargetPath='%~dp0restart_calendar.cmd';$r.WorkingDirectory='%~dp0';$r.IconLocation='%~dp0assets\family_calendar_hub.ico';$r.Save()"
echo [OK] Desktop Start and Restart shortcuts created.
echo [OK] Persistent data: %LOCALAPPDATA%\FamilyCalendarHub
echo [Network] Configuring Windows Firewall for LAN access on TCP port 8090...
netsh advfirewall firewall show rule name="Family Calendar Hub 8090" >nul 2>&1
if errorlevel 1 (
  netsh advfirewall firewall add rule name="Family Calendar Hub 8090" dir=in action=allow protocol=TCP localport=8090 profile=private >nul 2>&1
  if errorlevel 1 (
    echo [Network] Administrator permission is needed to open the firewall. Requesting UAC...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath netsh.exe -Verb RunAs -Wait -ArgumentList 'advfirewall firewall add rule name="Family Calendar Hub 8090" dir=in action=allow protocol=TCP localport=8090 profile=private'"
  )
)
for /f "usebackq delims=" %%I in (`powershell -NoProfile -Command "$x=Get-NetIPConfiguration ^| Where-Object { $_.IPv4DefaultGateway -and $_.IPv4Address } ^| Select-Object -First 1; if($x){$x.IPv4Address.IPAddress}"`) do set "FCH_LAN_IP=%%I"
if defined FCH_LAN_IP (
  echo [Network] Other devices can open: http://!FCH_LAN_IP!:8090
) else echo [Network] Server listens on all interfaces at TCP 8090.
call start_calendar.cmd
echo Installation complete.
pause
