@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe exit /b 2
start "Family Calendar Hub Watchdog" /min "%~dp0.venv\Scripts\python.exe" "%~dp0watchdog.py"
timeout /t 2 /nobreak >nul
start "" "http://localhost:8090"
