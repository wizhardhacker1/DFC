# Family Calendar Hub v12

This update adds both Apple Calendar connection choices under **Settings → Calendar Connections**.

## Apple iCloud — Private CalDAV
Use this when you do **not** want to make the calendar public.

1. In your Apple Account, create an **app-specific password**.
2. In Family Calendar Hub, open **Settings → Calendar Connections → Add Connection**.
3. Choose **Apple iCloud — Private CalDAV**.
4. Select the family member, enter the Apple Account email and app-specific password, and leave the server as `https://caldav.icloud.com`.
5. Save, then press **Sync**.

The password is encrypted before it is stored in the local Family Calendar Hub profile. The current v12 CalDAV connector imports/synchronizes iCloud events into the wall calendar. Editing an imported Apple event in Family Calendar Hub is not yet pushed back to iCloud in this package, so treat the iCloud source as authoritative for edits.

## Apple Calendar Link — Read Only
Use this for the simplest setup when a public/subscription link is acceptable.

1. In Apple Calendar/iCloud, enable the calendar's **Public Calendar** sharing option and copy its `webcal://` link.
2. Add a connection and choose **Apple Calendar Link — Read Only**.
3. Paste the `webcal://` or ICS URL into the URL field.
4. Save and press **Sync**.

The calendar is imported read-only. No Apple password is required.

## Also included
- Deleted household members remain filtered/cleaned from Calendar Connections.
- Existing persistent family data remains under the Family Calendar Hub profile directory and is not intentionally overwritten by an application update.
- Apple connection credentials are stored encrypted using a local integration key.
- Existing Ask AI, Piper voice, backups, watchdog, weather, holidays, and touchscreen UI remain included.

## Installation
Use `install_windows.bat` on Windows or `install_linux.sh` on Linux. The installer installs the Python dependencies required for Apple CalDAV and ICS support.


## v12 Neural Voice Repair
- Piper now uses its Python API directly instead of depending on CLI/PATH behavior.
- Windows/Linux installers fail clearly if Piper, the voice download, or real WAV synthesis verification fails.
- Settings > Voice Assistant now shows Engine, Voice Model, and Audio Test status.
- **Repair / Download Voice** repairs Piper and downloads/verifies the currently selected voice without reinstalling the calendar.
- Piper mode never silently falls back to the Windows/browser robotic voice.
- The obsolete “re-run v9 installer” message has been removed.

## v15 Windows neural voice repair

v15 fixes the Windows `onnxruntime_pybind11_state` / `DLL load failed` failure seen during Piper setup.

The Windows installer now performs an explicit five-stage voice preflight:
1. Import ONNX Runtime and verify its native DLLs can load.
2. If that fails, download the official Microsoft Visual C++ x64 Redistributable from Microsoft's permanent `aka.ms` link and install/repair it.
3. Re-test ONNX Runtime; if necessary, force-reinstall the CPU ONNX Runtime wheel and test again.
4. Install/import Piper and download the selected Lessac neural voice model.
5. Generate a real WAV file and verify it before reporting the neural voice as ready.

The installer no longer mislabels an ONNX DLL/import failure as a voice-model download failure. Exit code 3010 from the Microsoft runtime installer is treated as success-with-restart-required. If ONNX still cannot load after repair, the installer stops with a specific message rather than continuing with a broken voice installation.

Existing Family Calendar Hub data remains under `%LOCALAPPDATA%\\FamilyCalendarHub` and is not replaced by this upgrade.


## v15 Windows installer correction
The VC++ redistributable launch now uses delayed expansion inside the ONNX repair block, validates that the downloaded installer exists and is non-empty, and executes the resolved absolute TEMP path. This fixes the v13 empty quoted command / Windows exit 9009 failure.

## v16 Apple recurrence, dates, sync, and voice
- Apple ICS and iCloud CalDAV recurring events are expanded from RRULE/RDATE/EXDATE, including recurrence exceptions, for a rolling 120-day past / 730-day future window.
- Each expanded occurrence receives a unique external key, preventing a repeating series from collapsing into one database row.
- DATE-only/all-day Apple events are kept on their actual calendar date instead of being parsed by the browser as UTC and appearing one day early.
- Enabled Apple connections refresh automatically at startup and every 5 minutes. Manual Sync remains available.
- Calendar Connections now shows the 5-minute auto-sync cadence and last successful sync time.
- Appointment/reminder speech now uses the selected Piper neural voice too; it no longer always calls the browser/system speech engine.
- A successful Voice Repair automatically selects Piper as the active voice engine.

## v17 — Apple duplicate cleanup + LAN access

- Apple ICS and iCloud CalDAV sources now refresh as a clean remote snapshot on each successful sync. This removes stale recurrence masters and old expanded instances instead of accumulating them.
- A database migration removes exact legacy remote duplicates and enforces one stored row per source/remote occurrence key.
- Sync remains every 5 minutes, with an initial refresh shortly after startup and manual Sync support.
- The web server binds to `0.0.0.0:8090`, not loopback only.
- Windows setup creates a Private-network inbound firewall rule for TCP 8090 (requesting UAC when required) and prints the primary LAN URL.
- Linux setup prints the detected LAN URL and notes the UFW command if UFW is installed.
- Other devices on the same trusted LAN can use `http://SERVER-LAN-IP:8090`.

After upgrading from v16, press Sync once for each Apple connection (or wait for the automatic startup sync). The successful sync replaces the old imported snapshot, which removes duplicate recurrence rows left by earlier versions.

## v18 — Windows / Debian feature parity
- Windows and Debian/Linux both bind the web server to `0.0.0.0:8090` for LAN access.
- Both installers detect/display the primary LAN address and configure TCP 8090 when a supported host firewall is active.
- Both support login startup, system-boot startup, and manual startup with watchdog recovery.
- Both provision Ollama + `llama3.2:3b`, Piper TTS, the Lessac neural voice, and verify neural speech by generating a real WAV before completing installation.
- Debian automatically repairs common prerequisites (`python3-venv`, `curl`, `ca-certificates`) when apt is available.
- Linux voice downloads now use native `curl`/system CA trust first, matching the Windows strategy and avoiding Python certificate-store differences.
- The same persistent-data model is retained: application upgrades do not replace calendar data, backups, logs, or downloaded voices.

## v19 — Optional Local AI
- Ollama and llama3.2:3b are no longer mandatory installation dependencies.
- Windows and Debian/Linux installers ask whether to install Local AI; the default is **No**.
- Choosing No does not install, start, enable, or contact Ollama. Calendar, Apple sync, recurrence, reminders, Piper neural voice, weather, backups, and LAN access remain available.
- Settings → Local AI now has an Enable Local AI toggle. When disabled, AI endpoints do not contact Ollama and Ask AI reports that Local AI is disabled.
- Choosing Yes preserves the existing local Ollama + llama3.2:3b workflow.
