@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'FamilyCalendarHub' -or $_.CommandLine -match 'watchdog.py' -or $_.CommandLine -match 'run.py' } | ForEach-Object { if ($_.ProcessId -ne $PID) { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } }"
timeout /t 2 /nobreak >nul
start "Family Calendar Hub Watchdog" /min "%~dp0.venv\Scripts\python.exe" "%~dp0watchdog.py"
timeout /t 3 /nobreak >nul
start "" "http://localhost:8090"
