import os, subprocess, sys, time, urllib.request
BASE=os.path.dirname(os.path.abspath(__file__))
RUN=os.path.join(BASE,'run.py')
LOGROOT=os.path.join(os.environ.get('LOCALAPPDATA',os.path.expanduser('~')),'FamilyCalendarHub','logs') if os.name=='nt' else os.path.join(os.environ.get('XDG_DATA_HOME',os.path.join(os.path.expanduser('~'),'.local','share')),'FamilyCalendarHub','logs')
os.makedirs(LOGROOT,exist_ok=True)
log=open(os.path.join(LOGROOT,'watchdog.log'),'a',buffering=1,encoding='utf-8')
proc=None

def healthy():
 try:
  with urllib.request.urlopen('http://127.0.0.1:8090/api/health',timeout=4) as r: return r.status==200
 except: return False
while True:
 if proc is None or proc.poll() is not None:
  log.write(f'[{time.ctime()}] starting calendar backend\n')
  proc=subprocess.Popen([sys.executable,RUN],cwd=BASE,stdout=log,stderr=log)
  time.sleep(5)
 elif not healthy():
  log.write(f'[{time.ctime()}] health check failed; restarting backend\n')
  proc.terminate()
  try: proc.wait(8)
  except: proc.kill()
  proc=None
  time.sleep(2)
 time.sleep(10)
