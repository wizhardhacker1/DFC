#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")" && pwd)"; cd "$BASE"
PORT=8090
DATA="${XDG_DATA_HOME:-$HOME/.local/share}/FamilyCalendarHub"
VOICE_DIR="$DATA/voices"
echo '=================================================='
echo ' Family Calendar Hub v18 - Debian/Linux Installer'
echo '=================================================='

# Debian-family prerequisite repair. Do not fail merely because apt is unavailable
# on another Linux distribution.
if command -v apt-get >/dev/null 2>&1; then
  missing=()
  command -v python3 >/dev/null 2>&1 || missing+=(python3)
  command -v curl >/dev/null 2>&1 || missing+=(curl)
  [[ -f /etc/ssl/certs/ca-certificates.crt ]] || missing+=(ca-certificates)
  python3 -m venv --help >/dev/null 2>&1 || missing+=(python3-venv)
  if ((${#missing[@]})); then
    echo "[Prerequisites] Installing: ${missing[*]}"
    sudo apt-get update
    sudo apt-get install -y "${missing[@]}"
  fi
fi
command -v python3 >/dev/null || { echo 'ERROR: Python 3 is required.'; exit 1; }
command -v curl >/dev/null || { echo 'ERROR: curl is required.'; exit 1; }
mkdir -p "$DATA"/{data,backups,logs,voices}

if ! command -v ollama >/dev/null 2>&1; then
  echo '[AI] Ollama not detected. Installing...'
  curl -fsSL https://ollama.com/install.sh | sh
fi
curl -fsS http://127.0.0.1:11434/api/tags >/dev/null 2>&1 || { nohup ollama serve >"$DATA/logs/ollama.log" 2>&1 & sleep 3; }
ollama list | grep -Fq 'llama3.2:3b' || ollama pull llama3.2:3b

if [[ ! -d .venv ]]; then
  if ! python3 -m venv .venv; then
    if command -v apt-get >/dev/null 2>&1; then
      echo '[Python] venv support missing; installing python3-venv...'
      sudo apt-get update && sudo apt-get install -y python3-venv
      python3 -m venv .venv
    else
      echo 'ERROR: Python venv support is required.'; exit 1
    fi
  fi
fi
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt

echo '[Voice 1/4] Verifying ONNX Runtime...'
python -c "import onnxruntime; print('ONNX Runtime', onnxruntime.__version__, 'native test passed')" || {
  echo '[Voice] Repairing ONNX Runtime CPU package...'
  python -m pip uninstall -y onnxruntime >/dev/null 2>&1 || true
  python -m pip install --no-cache-dir --force-reinstall 'onnxruntime>=1.20,<2'
  python -c "import onnxruntime; print('ONNX Runtime', onnxruntime.__version__, 'native test passed')" || { echo 'ERROR: ONNX Runtime cannot load.'; exit 1; }
}
echo '[Voice 2/4] Installing Piper neural TTS...'
python -m pip install --upgrade 'piper-tts>=1.3.0'
python -c "from piper import PiperVoice; print('Piper import passed')" || { echo 'ERROR: Piper cannot load.'; exit 1; }

echo '[Voice 3/4] Installing/verifying Lessac neural voice with Linux TLS...'
MODEL="$VOICE_DIR/en_US-lessac-medium.onnx"
CONFIG="$VOICE_DIR/en_US-lessac-medium.onnx.json"
BASEURL='https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/lessac/medium/en_US-lessac-medium.onnx'
download_file() {
  local url="$1" dest="$2" min="$3"
  if [[ -f "$dest" ]] && [[ $(stat -c%s "$dest") -ge "$min" ]]; then return 0; fi
  rm -f "$dest.part"
  curl --fail --location --retry 3 --connect-timeout 20 --output "$dest.part" "$url"
  [[ -f "$dest.part" ]] && [[ $(stat -c%s "$dest.part") -ge "$min" ]] || { rm -f "$dest.part"; echo "ERROR: Incomplete voice download: $dest"; exit 1; }
  mv -f "$dest.part" "$dest"
}
download_file "$BASEURL" "$MODEL" 1000000
download_file "$BASEURL.json" "$CONFIG" 1000

echo '[Voice 4/4] Generating a real WAV test...'
VOICE_DIR="$VOICE_DIR" python - <<'PYVOICE'
import os,wave,tempfile
from piper import PiperVoice
p=os.path.join(os.environ['VOICE_DIR'],'en_US-lessac-medium.onnx')
assert os.path.exists(p) and os.path.exists(p+'.json')
v=PiperVoice.load(p); out=os.path.join(tempfile.gettempdir(),'fch_voice_test.wav')
with wave.open(out,'wb') as w: v.synthesize_wav('Family Calendar Hub voice test.',w)
assert os.path.getsize(out)>1000
os.remove(out)
PYVOICE
echo '[OK] Neural voice verified end-to-end.'

cat > "$BASE/start_calendar.sh" <<EOS
#!/usr/bin/env bash
cd "$BASE"
exec "$BASE/.venv/bin/python" "$BASE/watchdog.py"
EOS
chmod +x "$BASE/start_calendar.sh"

# Remove prior service definitions before applying the selected equivalent startup mode.
systemctl --user disable --now family-calendar-hub.service >/dev/null 2>&1 || true
sudo systemctl disable --now family-calendar-hub.service >/dev/null 2>&1 || true
rm -f "$HOME/.config/systemd/user/family-calendar-hub.service"
if [[ -w /etc/systemd/system ]] || sudo -n true >/dev/null 2>&1; then sudo rm -f /etc/systemd/system/family-calendar-hub.service >/dev/null 2>&1 || true; fi

echo
echo 'Startup mode:'
echo '  1) Start automatically at user login (recommended for wall display)'
echo '  2) Start automatically at system boot'
echo '  3) Manual startup only'
read -rp 'Choose 1, 2, or 3: ' mode
mkdir -p "$HOME/.config/systemd/user"
if [[ "$mode" == 1 ]]; then
 cat > "$HOME/.config/systemd/user/family-calendar-hub.service" <<EOS
[Unit]
Description=Family Calendar Hub
After=network-online.target
Wants=network-online.target
[Service]
Type=simple
ExecStart=$BASE/start_calendar.sh
Restart=always
RestartSec=5
[Install]
WantedBy=default.target
EOS
 systemctl --user daemon-reload
 systemctl --user enable --now family-calendar-hub.service
elif [[ "$mode" == 2 ]]; then
 sudo tee /etc/systemd/system/family-calendar-hub.service >/dev/null <<EOS
[Unit]
Description=Family Calendar Hub
After=network-online.target
Wants=network-online.target
[Service]
Type=simple
User=$USER
Environment=HOME=$HOME
ExecStart=$BASE/start_calendar.sh
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
EOS
 sudo systemctl daemon-reload
 sudo systemctl enable --now family-calendar-hub.service
else
 nohup "$BASE/start_calendar.sh" >"$DATA/logs/startup.log" 2>&1 &
fi

mkdir -p "$HOME/Desktop"
cat > "$HOME/Desktop/Family Calendar Hub.desktop" <<EOS
[Desktop Entry]
Type=Application
Name=Family Calendar Hub
Exec=$BASE/start_calendar.sh
Icon=$BASE/assets/family_calendar_hub_logo.png
Terminal=false
EOS
cat > "$HOME/Desktop/Restart Family Calendar Hub.desktop" <<EOS
[Desktop Entry]
Type=Application
Name=Restart Family Calendar Hub
Exec=sh -c 'pkill -f "$BASE/watchdog.py" || true; pkill -f "$BASE/run.py" || true; sleep 2; "$BASE/start_calendar.sh"'
Icon=$BASE/assets/family_calendar_hub_logo.png
Terminal=false
EOS
chmod +x "$HOME/Desktop/Family Calendar Hub.desktop" "$HOME/Desktop/Restart Family Calendar Hub.desktop"

# Match Windows: make TCP 8090 reachable on the LAN when a supported firewall is active.
echo "[Network] Configuring Linux firewall for LAN access on TCP port $PORT..."
if command -v ufw >/dev/null 2>&1 && sudo ufw status 2>/dev/null | grep -qi '^Status: active'; then
  sudo ufw allow "$PORT/tcp" >/dev/null
  echo '[Network] UFW rule added.'
elif command -v firewall-cmd >/dev/null 2>&1 && sudo firewall-cmd --state >/dev/null 2>&1; then
  sudo firewall-cmd --permanent --add-port="$PORT/tcp" >/dev/null
  sudo firewall-cmd --reload >/dev/null
  echo '[Network] firewalld rule added.'
else
  echo '[Network] No active UFW/firewalld firewall detected; no firewall rule was required.'
fi

LAN_IP="$(ip route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src"){print $(i+1); exit}}')"
[[ -z "$LAN_IP" ]] && LAN_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
echo "[OK] Persistent data: $DATA"
echo "[Network] Server binds to 0.0.0.0:$PORT"
[[ -n "$LAN_IP" ]] && echo "[Network] Other devices can open: http://$LAN_IP:$PORT"

echo 'Installation complete.'
