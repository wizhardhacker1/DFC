from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timedelta, date
import sqlite3, os, uuid, json, urllib.request, urllib.parse, zipfile, tempfile, shutil, hashlib, threading, time, base64, subprocess, sys, socket

BASE=os.path.dirname(__file__)
# Persistent family data is intentionally outside the application payload so upgrades cannot overwrite it.
if os.name=='nt': DATA_ROOT=os.path.join(os.environ.get('LOCALAPPDATA',os.path.expanduser('~')),'FamilyCalendarHub')
else: DATA_ROOT=os.path.join(os.environ.get('XDG_DATA_HOME',os.path.join(os.path.expanduser('~'),'.local','share')),'FamilyCalendarHub')
DATA_DIR=os.path.join(DATA_ROOT,'data'); BACKUPS=os.path.join(DATA_ROOT,'backups')
os.makedirs(DATA_DIR,exist_ok=True); os.makedirs(BACKUPS,exist_ok=True)
DB=os.path.join(DATA_DIR,'family_calendar.db')
legacy=os.path.join(BASE,'family_calendar.db')
if not os.path.exists(DB) and os.path.exists(legacy): shutil.copy2(legacy,DB)
OLLAMA_URL='http://127.0.0.1:11434'
APP_VERSION='2026.9-v18'
app=FastAPI(title='Family Calendar Hub')

def conn():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c

def init():
 c=conn(); c.executescript('''
 CREATE TABLE IF NOT EXISTS people(id TEXT PRIMARY KEY,name TEXT NOT NULL,color TEXT NOT NULL,role TEXT DEFAULT 'member',avatar TEXT DEFAULT '');
 CREATE TABLE IF NOT EXISTS sources(id TEXT PRIMARY KEY,person_id TEXT,name TEXT,provider TEXT DEFAULT 'local',external_id TEXT,sync_enabled INTEGER DEFAULT 1,connection_status TEXT DEFAULT 'local',FOREIGN KEY(person_id) REFERENCES people(id));
 CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY,title TEXT NOT NULL,start TEXT NOT NULL,end TEXT NOT NULL,location TEXT DEFAULT '',notes TEXT DEFAULT '',source_id TEXT,all_day INTEGER DEFAULT 0,remind_60 INTEGER DEFAULT 1,remind_15 INTEGER DEFAULT 1,recurrence TEXT DEFAULT '',updated_at TEXT NOT NULL,FOREIGN KEY(source_id) REFERENCES sources(id));
 CREATE TABLE IF NOT EXISTS event_people(event_id TEXT,person_id TEXT,PRIMARY KEY(event_id,person_id));
 CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT);
 ''')
 if not c.execute('select 1 from people').fetchone():
  for name,color,role in [('Mom','#f59ab8','admin'),('Dad','#74a7f7','admin'),('Kid 1','#79cf9a','member'),('Kid 2','#b28ae8','member')]:
   pid=str(uuid.uuid4()); sid=str(uuid.uuid4()); c.execute('insert into people(id,name,color,role,avatar) values(?,?,?,?,?)',(pid,name,color,role,'')); c.execute('insert into sources(id,person_id,name) values(?,?,?)',(sid,pid,f'{name} Calendar'))
 # lightweight migrations for existing installs
 try: c.execute("alter table people add column avatar TEXT DEFAULT ''")
 except sqlite3.OperationalError: pass
 try: c.execute("alter table sources add column connection_status TEXT DEFAULT 'local'")
 except sqlite3.OperationalError: pass
 for col,ddl in [('username',"TEXT DEFAULT ''"),('secret_enc',"TEXT DEFAULT ''"),('calendar_url',"TEXT DEFAULT ''"),('last_sync',"TEXT DEFAULT ''"),('last_error',"TEXT DEFAULT ''")]:
  try: c.execute(f"alter table sources add column {col} {ddl}")
  except sqlite3.OperationalError: pass
 try: c.execute("alter table events add column external_uid TEXT DEFAULT ''")
 except sqlite3.OperationalError: pass
 # Remove exact legacy remote duplicates before enforcing one row per remote occurrence.
 c.execute("DELETE FROM event_people WHERE event_id IN (SELECT e.id FROM events e JOIN events k ON e.source_id=k.source_id AND e.external_uid=k.external_uid AND e.external_uid<>'' AND e.rowid>k.rowid)")
 c.execute("DELETE FROM events WHERE rowid NOT IN (SELECT MIN(rowid) FROM events GROUP BY source_id, external_uid) AND external_uid<>''")
 try: c.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_events_remote_instance ON events(source_id,external_uid) WHERE external_uid<>''")
 except sqlite3.OperationalError: pass
 for k,v in [('muted','0'),('volume','0.85'),('spoken_alerts','1'),('quiet_enabled','1'),('quiet_start','21:00'),('quiet_end','07:00'),('weather_location','Ridgecrest, CA'),('weather_units','fahrenheit'),('show_holidays','1'),('holiday_country','US'),('auto_backup','1'),('backup_retention','14'),('local_ai_model','llama3.2:3b'),('tts_engine','piper'),('tts_voice','en_US-lessac-medium'),('tts_rate','1.0')]: c.execute('insert or ignore into settings values(?,?)',(k,v))
 c.commit(); c.close()
init()



def _sha256(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
 return h.hexdigest()

def create_backup(kind='manual'):
 stamp=datetime.now().strftime('%Y%m%d_%H%M%S'); name=f'family_calendar_{kind}_{stamp}.fcalbackup'; out=os.path.join(BACKUPS,name)
 with tempfile.TemporaryDirectory() as td:
  snap=os.path.join(td,'family_calendar.db'); src=sqlite3.connect(DB); dst=sqlite3.connect(snap); src.backup(dst); dst.close(); src.close()
  manifest={'format':'FamilyCalendarBackup','format_version':1,'app_version':APP_VERSION,'created_at':datetime.now().isoformat(),'kind':kind,'database_sha256':_sha256(snap)}
  with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z: z.write(snap,'family_calendar.db'); z.writestr('manifest.json',json.dumps(manifest,indent=2))
 prune_backups(); return out

def prune_backups():
 try:
  c=conn(); r=c.execute("select v from settings where k='backup_retention'").fetchone(); c.close(); keep=max(1,int(r['v'] if r else 14))
 except: keep=14
 fs=sorted([os.path.join(BACKUPS,x) for x in os.listdir(BACKUPS) if x.endswith('.fcalbackup')],key=os.path.getmtime,reverse=True)
 for f in fs[keep:]:
  try: os.remove(f)
  except: pass

def validate_backup(path):
 try:
  with zipfile.ZipFile(path) as z:
   if 'manifest.json' not in z.namelist() or 'family_calendar.db' not in z.namelist(): return False,'Missing backup manifest or database'
   m=json.loads(z.read('manifest.json')); data=z.read('family_calendar.db')
   if m.get('format')!='FamilyCalendarBackup': return False,'Not a Family Calendar backup'
   if hashlib.sha256(data).hexdigest()!=m.get('database_sha256'): return False,'Backup checksum failed'
   with tempfile.NamedTemporaryFile(suffix='.db',delete=False) as f: f.write(data); tmp=f.name
   try:
    c=sqlite3.connect(tmp); tables={x[0] for x in c.execute("select name from sqlite_master where type='table'")}; c.close()
    if not {'people','sources','events','event_people','settings'}.issubset(tables): return False,'Backup database is incomplete'
   finally: os.unlink(tmp)
   return True,m
 except Exception as e: return False,str(e)

def auto_backup_loop():
 while True:
  time.sleep(3600)
  try:
   c=conn(); on=c.execute("select v from settings where k='auto_backup'").fetchone(); c.close()
   if not on or on['v']!='1': continue
   autos=[os.path.join(BACKUPS,x) for x in os.listdir(BACKUPS) if '_auto_' in x and x.endswith('.fcalbackup')]
   if not autos or time.time()-max(os.path.getmtime(x) for x in autos)>=23*3600: create_backup('auto')
  except Exception: pass

threading.Thread(target=auto_backup_loop,daemon=True).start()

class PersonIn(BaseModel): name:str; color:str='#74a7f7'; role:str='member'; avatar:str=''
class SourceIn(BaseModel): person_id:str; name:str; provider:str='local'; external_id:str=''; sync_enabled:bool=True; username:str=''; password:str=''; calendar_url:str=''
class EventIn(BaseModel): title:str; start:str; end:str; location:str=''; notes:str=''; person_ids:list[str]=[]; all_day:bool=False; remind_60:bool=True; remind_15:bool=True; recurrence:str=''; source_id:Optional[str]=None

@app.get('/api/people')
def people():
 c=conn(); r=[dict(x) for x in c.execute('select * from people order by name')]; c.close(); return r
@app.post('/api/people')
def add_person(p:PersonIn):
 c=conn(); pid=str(uuid.uuid4()); sid=str(uuid.uuid4()); c.execute('insert into people(id,name,color,role,avatar) values(?,?,?,?,?)',(pid,p.name,p.color,p.role,p.avatar)); c.execute('insert into sources(id,person_id,name) values(?,?,?)',(sid,pid,p.name+' Calendar')); c.commit(); c.close(); return {'id':pid}
@app.delete('/api/people/{pid}')
def del_person(pid:str):
 c=conn(); c.execute('delete from event_people where person_id=?',(pid,)); c.execute('update events set source_id=NULL where source_id in (select id from sources where person_id=?)',(pid,)); c.execute('delete from sources where person_id=?',(pid,)); c.execute('delete from people where id=?',(pid,)); c.commit(); c.close(); return {'ok':True}
@app.put('/api/people/{pid}')
def edit_person(pid:str,p:PersonIn):
 c=conn(); c.execute('update people set name=?,color=?,role=?,avatar=? where id=?',(p.name,p.color,p.role,p.avatar,pid)); c.commit(); c.close(); return {'ok':True}


def _fernet():
 from cryptography.fernet import Fernet
 keyfile=os.path.join(DATA_ROOT,'integration.key')
 if not os.path.exists(keyfile):
  with open(keyfile,'wb') as f: f.write(Fernet.generate_key())
 try:
  if os.name!='nt': os.chmod(keyfile,0o600)
 except: pass
 return Fernet(open(keyfile,'rb').read().strip())

def _enc(v): return _fernet().encrypt(v.encode()).decode() if v else ''
def _dec(v):
 try: return _fernet().decrypt(v.encode()).decode() if v else ''
 except: return ''

def _source_public(d):
 d=dict(d); d.pop('secret_enc',None); d['has_password']=bool(dict(d).get('secret_enc','')) if 'secret_enc' in dict(d) else False; return d

@app.get('/api/sources')
def sources():
 c=conn()
 # Remove legacy/orphaned calendar connections whose household member no longer exists.
 c.execute('delete from sources where person_id not in (select id from people)')
 c.commit()
 r=[_source_public(x) for x in c.execute('select s.* from sources s join people p on p.id=s.person_id order by p.name,s.name')]
 c.close(); return r
@app.post('/api/sources')
def add_source(s:SourceIn):
 c=conn()
 if not c.execute('select 1 from people where id=?',(s.person_id,)).fetchone(): c.close(); raise HTTPException(400,'That family member no longer exists')
 sid=str(uuid.uuid4()); status='local' if s.provider=='local' else 'ready_to_sync'; c.execute('insert into sources(id,person_id,name,provider,external_id,sync_enabled,connection_status,username,secret_enc,calendar_url) values(?,?,?,?,?,?,?,?,?,?)',(sid,s.person_id,s.name,s.provider,s.external_id,int(s.sync_enabled),status,s.username,_enc(s.password),s.calendar_url)); c.commit(); c.close(); return {'id':sid,'connection_status':status}
@app.put('/api/sources/{sid}')
def edit_source(sid:str,s:SourceIn):
 c=conn()
 if not c.execute('select 1 from people where id=?',(s.person_id,)).fetchone(): c.close(); raise HTTPException(400,'That family member no longer exists')
 old=c.execute('select secret_enc from sources where id=?',(sid,)).fetchone(); secret=_enc(s.password) if s.password else (old['secret_enc'] if old else ''); c.execute('update sources set person_id=?,name=?,provider=?,external_id=?,sync_enabled=?,username=?,secret_enc=?,calendar_url=? where id=?',(s.person_id,s.name,s.provider,s.external_id,int(s.sync_enabled),s.username,secret,s.calendar_url,sid)); c.commit(); c.close(); return {'ok':True}
@app.delete('/api/sources/{sid}')
def delete_source(sid:str):
 c=conn(); local=c.execute("select provider from sources where id=?",(sid,)).fetchone();
 if local and local['provider']=='local': raise HTTPException(400,'The built-in local calendar cannot be deleted')
 c.execute('delete from sources where id=?',(sid,)); c.commit(); c.close(); return {'ok':True}


def _dt_iso(v):
 if not v: return ''
 if hasattr(v,'dt'): v=v.dt
 # DATE-only values must stay on their calendar date.  JavaScript treats a bare
 # YYYY-MM-DD as UTC, which shifts Apple all-day events to the prior day in US time zones.
 if isinstance(v,date) and not isinstance(v,datetime): return v.isoformat()+'T00:00:00'
 if isinstance(v,datetime): return v.isoformat()
 return str(v)

def _instance_key(comp):
 uid=str(comp.get('UID') or uuid.uuid4())
 rid=comp.get('RECURRENCE-ID')
 if rid: return uid+'|'+_dt_iso(rid)
 ds=comp.get('DTSTART')
 return uid+'|'+_dt_iso(ds)

def _upsert_remote_event(c, source, uid, title, start, end, location='', notes='', all_day=0, recurrence=''):
 row=c.execute('select id from events where source_id=? and external_uid=?',(source['id'],uid)).fetchone()
 now=datetime.now().isoformat(); eid=row['id'] if row else str(uuid.uuid4())
 if row: c.execute('update events set title=?,start=?,end=?,location=?,notes=?,all_day=?,recurrence=?,updated_at=? where id=?',(title,start,end,location,notes,int(all_day),recurrence,now,eid))
 else: c.execute('insert into events(id,title,start,end,location,notes,source_id,all_day,recurrence,updated_at,external_uid) values(?,?,?,?,?,?,?,?,?,?,?)',(eid,title,start,end,location,notes,source['id'],int(all_day),recurrence,now,uid))
 c.execute('insert or ignore into event_people(event_id,person_id) values(?,?)',(eid,source['person_id']))

def _store_component(c,source,comp):
 ds=comp.get('DTSTART'); de=comp.get('DTEND')
 if not ds: return 0
 rawdt=ds.dt if hasattr(ds,'dt') else ds
 all_day=isinstance(rawdt,date) and not isinstance(rawdt,datetime)
 st=_dt_iso(ds); en=_dt_iso(de) if de else st
 recurrence=str(comp.get('RRULE') or '')
 _upsert_remote_event(c,source,_instance_key(comp),str(comp.get('SUMMARY') or 'Untitled'),st,en,str(comp.get('LOCATION') or ''),str(comp.get('DESCRIPTION') or ''),all_day,recurrence)
 return 1

def _expanded_components(cal, start, end):
 """Expand RRULE/RDATE/EXDATE and Apple recurrence exceptions into real instances."""
 import recurring_ical_events
 try:
  return list(recurring_ical_events.of(cal).between(start,end))
 except Exception:
  # A malformed third-party feed should still import its non-recurring VEVENTs.
  return list(cal.walk('VEVENT'))

def _clear_remote_source_events(c, source_id):
 # Imported Apple events mirror the remote calendar. Replacing the source snapshot
 # on each successful sync prevents legacy masters/stale recurrence instances from
 # accumulating beside newly expanded occurrences. Local calendar events are untouched.
 ids=[r['id'] for r in c.execute("select id from events where source_id=? and external_uid<>''",(source_id,))]
 if ids:
  c.executemany('delete from event_people where event_id=?',[(x,) for x in ids])
  c.executemany('delete from events where id=?',[(x,) for x in ids])

def _sync_ics(c, source):
 from icalendar import Calendar
 url=source['external_id'] or source['calendar_url']
 if not url: raise ValueError('Enter the Apple public ICS/webcal URL')
 if url.startswith('webcal://'): url='https://'+url[len('webcal://'):]
 req=urllib.request.Request(url,headers={'User-Agent':'FamilyCalendarHub/17'})
 with urllib.request.urlopen(req,timeout=30) as r: raw=r.read()
 cal=Calendar.from_ical(raw)
 window_start=datetime.now()-timedelta(days=120); window_end=datetime.now()+timedelta(days=730)
 components=_expanded_components(cal,window_start,window_end)
 _clear_remote_source_events(c,source['id'])
 count=0
 for comp in components: count+=_store_component(c,source,comp)
 return count

def _caldav_calendar(source):
 import caldav
 client=caldav.DAVClient(url=source['external_id'] or 'https://caldav.icloud.com',username=source['username'],password=_dec(source['secret_enc']))
 principal=client.principal(); calendars=principal.calendars()
 if not calendars: raise ValueError('No iCloud calendars were found for this Apple account')
 wanted=(source['calendar_url'] or '').strip()
 if wanted:
  for cal in calendars:
   if str(cal.url)==wanted or getattr(cal,'name','')==wanted: return cal
 return calendars[0]

def _sync_caldav(c, source):
 from icalendar import Calendar
 cal=_caldav_calendar(source); count=0
 window_start=datetime.now()-timedelta(days=120); window_end=datetime.now()+timedelta(days=730)
 # Fetch the complete snapshot first. Only replace the local mirror after every
 # remote object parsed successfully, so a network failure cannot erase the cache.
 components=[]
 for remote in cal.search(start=window_start,end=window_end,event=True,expand=False):
  parsed=Calendar.from_ical(remote.data)
  components.extend(_expanded_components(parsed,window_start,window_end))
 _clear_remote_source_events(c,source['id'])
 for comp in components: count+=_store_component(c,source,comp)
 return count

def _sync_one_source(source):
 c=conn()
 try:
  if source['provider']=='apple_ics': count=_sync_ics(c,source)
  elif source['provider']=='apple_caldav': count=_sync_caldav(c,source)
  else: return 0
  stamp=datetime.now().isoformat(); c.execute("update sources set connection_status='connected',last_sync=?,last_error='' where id=?",(stamp,source['id'])); c.commit(); return count
 except Exception as e:
  c.execute("update sources set connection_status='error',last_error=? where id=?",(str(e)[:500],source['id'])); c.commit(); raise
 finally: c.close()

def _sync_enabled_sources():
 c=conn(); rows=[dict(x) for x in c.execute("select * from sources where sync_enabled=1 and provider in ('apple_ics','apple_caldav')")]; c.close()
 for source in rows:
  try: _sync_one_source(source)
  except Exception as e: print('[Calendar Sync]',source.get('name'),e)

def _calendar_sync_loop():
 # Initial refresh shortly after startup, then every five minutes.
 time.sleep(8)
 while True:
  _sync_enabled_sources(); time.sleep(300)

@app.on_event('startup')
def _start_calendar_sync():
 threading.Thread(target=_calendar_sync_loop,daemon=True,name='calendar-sync').start()

@app.post('/api/sources/sync-all')
def sync_all_sources():
 _sync_enabled_sources(); return {'ok':True,'interval_seconds':300}

@app.post('/api/sources/{sid}/sync')
def sync_source(sid:str):
 c=conn(); row=c.execute('select * from sources where id=?',(sid,)).fetchone(); c.close()
 if not row: raise HTTPException(404,'Connection not found')
 source=dict(row)
 try:
  count=_sync_one_source(source)
  c=conn(); r=c.execute('select last_sync from sources where id=?',(sid,)).fetchone(); c.close()
  return {'ok':True,'count':count,'last_sync':r['last_sync'] if r else '','interval_seconds':300}
 except Exception as e: raise HTTPException(502,'Calendar sync failed: '+str(e))

@app.get('/api/sources/{sid}/calendars')
def discover_calendars(sid:str):
 c=conn(); source=c.execute('select * from sources where id=?',(sid,)).fetchone(); c.close()
 if not source: raise HTTPException(404,'Connection not found')
 source=dict(source)
 if source['provider']!='apple_caldav': raise HTTPException(400,'Calendar discovery is only for Apple iCloud / CalDAV')
 try:
  import caldav
  client=caldav.DAVClient(url=source['external_id'] or 'https://caldav.icloud.com',username=source['username'],password=_dec(source['secret_enc']))
  return [{'name':getattr(x,'name','Calendar'),'url':str(x.url)} for x in client.principal().calendars()]
 except Exception as e: raise HTTPException(502,'Apple calendar discovery failed: '+str(e))

@app.get('/api/events')
def events(start:Optional[str]=None,end:Optional[str]=None):
 c=conn(); q='select e.* from events e'; args=[]; clauses=[]
 if start: clauses.append('e.end>=?'); args.append(start)
 if end: clauses.append('e.start<=?'); args.append(end)
 if clauses:q+=' where '+' and '.join(clauses)
 rows=[]
 for e in c.execute(q+' order by e.start',args):
  d=dict(e); d['person_ids']=[x['person_id'] for x in c.execute('select person_id from event_people where event_id=?',(e['id'],))]; rows.append(d)
 c.close(); return rows
@app.post('/api/events')
def add_event(e:EventIn):
 c=conn(); eid=str(uuid.uuid4()); source=e.source_id
 if not source and e.person_ids:
  z=c.execute('select id from sources where person_id=? limit 1',(e.person_ids[0],)).fetchone(); source=z['id'] if z else None
 c.execute('insert into events(id,title,start,end,location,notes,source_id,all_day,remind_60,remind_15,recurrence,updated_at,external_uid) values(?,?,?,?,?,?,?,?,?,?,?,?,?)',(eid,e.title,e.start,e.end,e.location,e.notes,source,int(e.all_day),int(e.remind_60),int(e.remind_15),e.recurrence,datetime.now().isoformat(),''))
 for p in e.person_ids:c.execute('insert or ignore into event_people values(?,?)',(eid,p))
 c.commit(); c.close(); return {'id':eid}
@app.put('/api/events/{eid}')
def edit_event(eid:str,e:EventIn):
 c=conn(); c.execute('update events set title=?,start=?,end=?,location=?,notes=?,all_day=?,remind_60=?,remind_15=?,recurrence=?,updated_at=? where id=?',(e.title,e.start,e.end,e.location,e.notes,int(e.all_day),int(e.remind_60),int(e.remind_15),e.recurrence,datetime.now().isoformat(),eid)); c.execute('delete from event_people where event_id=?',(eid,));
 for p in e.person_ids:c.execute('insert into event_people values(?,?)',(eid,p))
 c.commit(); c.close(); return {'ok':True}
@app.delete('/api/events/{eid}')
def delete_event(eid:str):
 c=conn(); c.execute('delete from event_people where event_id=?',(eid,)); c.execute('delete from events where id=?',(eid,)); c.commit(); c.close(); return {'ok':True}
def ollama_json(path, method='GET', payload=None, timeout=4):
 data=None if payload is None else json.dumps(payload).encode()
 req=urllib.request.Request(OLLAMA_URL+path,data=data,method=method,headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=timeout) as r: return json.loads(r.read().decode())

@app.get('/api/ai/status')
def ai_status():
 try:
  d=ollama_json('/api/tags'); models=[m.get('name','') for m in d.get('models',[])]
  c=conn(); row=c.execute("select v from settings where k='local_ai_model'").fetchone(); c.close(); selected=row['v'] if row else 'llama3.2:3b'
  return {'ollama':True,'models':models,'selected':selected,'required_installed':any(x=='llama3.2:3b' or x.startswith('llama3.2:3b') for x in models)}
 except Exception as e: return {'ollama':False,'models':[],'selected':'llama3.2:3b','required_installed':False,'error':str(e)}

@app.post('/api/ai/pull/{model:path}')
def ai_pull(model:str):
 try:
  # Non-streaming pull is intentionally explicit from Settings; installers provision llama3.2:3b automatically.
  return ollama_json('/api/pull','POST',{'model':model,'stream':False},timeout=1800)
 except Exception as e: raise HTTPException(503,'Ollama model pull failed: '+str(e))

class AskAIIn(BaseModel):
 question:str

def holiday_rows(year:int):
 from datetime import date
 def nth(y,m,weekday,n):
  d=date(y,m,1); return d+timedelta(days=(weekday-d.weekday())%7+7*(n-1))
 def last(y,m,weekday):
  d=date(y+1,1,1)-timedelta(days=1) if m==12 else date(y,m+1,1)-timedelta(days=1); return d-timedelta(days=(d.weekday()-weekday)%7)
 def obs(d):
  if d.weekday()==5:return d-timedelta(days=1)
  if d.weekday()==6:return d+timedelta(days=1)
  return d
 raw=[('New Year’s Day',date(year,1,1),True),('Martin Luther King Jr. Day',nth(year,1,0,3),False),('Washington’s Birthday',nth(year,2,0,3),False),('Memorial Day',last(year,5,0),False),('Juneteenth National Independence Day',date(year,6,19),True),('Independence Day',date(year,7,4),True),('Labor Day',nth(year,9,0,1),False),('Columbus Day / Indigenous Peoples’ Day',nth(year,10,0,2),False),('Veterans Day',date(year,11,11),True),('Thanksgiving Day',nth(year,11,3,4),False),('Christmas Day',date(year,12,25),True)]
 out=[]
 for name,d,observed in raw:
  out.append({'name':name,'date':d.isoformat(),'observed':False})
  if observed and obs(d)!=d: out.append({'name':name+' (Observed)','date':obs(d).isoformat(),'observed':True})
 return out

@app.post('/api/ai/ask')
def ai_ask(a:AskAIIn):
 q=a.question.strip()
 if not q: raise HTTPException(400,'No question was heard')
 c=conn()
 modelrow=c.execute("select v from settings where k='local_ai_model'").fetchone(); model=modelrow['v'] if modelrow else 'llama3.2:3b'
 people=[dict(x) for x in c.execute('select id,name,role from people order by name')]
 now=datetime.now(); end=(now+timedelta(days=30)).isoformat()
 ev=[]
 for e in c.execute('select id,title,start,end,location,notes from events where end>=? and start<=? order by start limit 250',(now.isoformat(),end)):
  d=dict(e); d['people']=[x['name'] for x in c.execute('select p.name from people p join event_people ep on ep.person_id=p.id where ep.event_id=?',(e['id'],))]; ev.append(d)
 c.close()
 holidays=[]
 for y in (now.year,now.year+1): holidays.extend(holiday_rows(y))
 future_holidays=[h for h in holidays if h['date'] >= now.date().isoformat()]
 # Resolve common calendar questions deterministically instead of making the LLM guess.
 qlow=q.lower()
 if 'holiday' in qlow and ('next' in qlow or 'upcoming' in qlow):
  if future_holidays:
   h=future_holidays[0]; hd=datetime.fromisoformat(h['date']).date()
   return {'answer':f"The next holiday on your calendar is {h['name']} on {hd.strftime('%A, %B %d')}.",'model':'calendar-engine','intent':'next_holiday'}
 context=json.dumps({'current_local_time':now.isoformat(),'family':people,'upcoming_events_next_30_days':ev,'calendar_holidays':future_holidays[:20]},ensure_ascii=False)
 system=('You are the private voice assistant for Family Calendar Hub. Answer briefly and naturally for speech. '
         'The supplied context includes family events and the holidays displayed by the calendar. Use those facts directly. '
         'Never say calendar information is unavailable when it is present in CALENDAR CONTEXT. '
         'Do not claim to add, edit, or delete an event; voice changes require a separate confirmation workflow. Do not use markdown.')
 try:
  r=ollama_json('/api/chat','POST',{'model':model,'stream':False,'messages':[{'role':'system','content':system+'\nCALENDAR CONTEXT: '+context},{'role':'user','content':q}]},timeout=120)
  answer=(r.get('message') or {}).get('content','').strip()
  if not answer: raise ValueError('Local AI returned an empty answer')
  return {'answer':answer,'model':model}
 except Exception as e: raise HTTPException(503,'Local AI could not answer: '+str(e))

class TTSIn(BaseModel):
 text:str

VOICE_DIR=os.path.join(DATA_ROOT,'voices')
os.makedirs(VOICE_DIR,exist_ok=True)

def _selected_voice():
 c=conn(); vals={x['k']:x['v'] for x in c.execute("select k,v from settings where k in ('tts_engine','tts_voice','tts_rate')")}; c.close()
 voice=''.join(ch for ch in vals.get('tts_voice','en_US-lessac-medium') if ch.isalnum() or ch in '_-')
 return vals,voice

def _voice_paths(voice):
 model=os.path.join(VOICE_DIR,voice+'.onnx'); return model,model+'.json'

def _piper_available():
 try:
  from piper import PiperVoice
  return True
 except Exception:
  return False

def _synthesize_piper(text,voice,out,rate=1.0):
 # Use Piper's Python API directly. This avoids PATH/CLI differences on Windows.
 import wave
 from piper import PiperVoice, SynthesisConfig
 model,config=_voice_paths(voice)
 if not os.path.exists(model) or not os.path.exists(config): raise RuntimeError('Selected neural voice files are missing')
 pv=PiperVoice.load(model)
 syn=SynthesisConfig(length_scale=max(.65,min(1.45,1.0/max(.5,float(rate)))))
 with wave.open(out,'wb') as wav:
  pv.synthesize_wav(text,wav,syn_config=syn)
 if not os.path.exists(out) or os.path.getsize(out)<1000: raise RuntimeError('Piper created no usable audio')
 return out

def _voice_download_urls(voice):
 # Piper voice repository layout: language-family/locale/dataset/quality/file.
 parts=voice.split('-')
 if len(parts)<3: raise RuntimeError('Unsupported Piper voice name: '+voice)
 locale,dataset,quality=parts[0],parts[1],'-'.join(parts[2:])
 family=locale.split('_',1)[0]
 base=f'https://huggingface.co/rhasspy/piper-voices/resolve/main/{family}/{locale}/{dataset}/{quality}/{voice}.onnx'
 return base,base+'.json'

def _download_voice(voice):
 os.makedirs(VOICE_DIR,exist_ok=True)
 model,config=_voice_paths(voice)
 urls=_voice_download_urls(voice)
 # On Windows use curl/Schannel so certificate validation uses the Windows trust store.
 # This avoids Microsoft Store Python CA-store failures seen with urllib.
 if os.name=='nt':
  curl=shutil.which('curl.exe') or shutil.which('curl')
  if not curl: raise RuntimeError('Windows curl.exe was not found')
  for dest,url,min_size in ((model,urls[0],1000000),(config,urls[1],1000)):
   if os.path.exists(dest) and os.path.getsize(dest)>=min_size: continue
   part=dest+'.part'
   try:
    if os.path.exists(part): os.remove(part)
    r=subprocess.run([curl,'--fail','--location','--retry','3','--connect-timeout','20','--output',part,url],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=300)
    if r.returncode!=0: raise RuntimeError('Windows TLS voice download failed: '+(r.stderr or r.stdout)[-900:])
    if not os.path.exists(part) or os.path.getsize(part)<min_size: raise RuntimeError('Downloaded voice file is incomplete')
    os.replace(part,dest)
   finally:
    if os.path.exists(part):
     try: os.remove(part)
     except: pass
 else:
  # Prefer the OS curl/CA trust store on Linux too. This keeps voice repair behavior
  # consistent with Windows and avoids Python CA bundle/proxy differences.
  curl=shutil.which('curl')
  if curl:
   for dest,url,min_size in ((model,urls[0],1000000),(config,urls[1],1000)):
    if os.path.exists(dest) and os.path.getsize(dest)>=min_size: continue
    part=dest+'.part'
    try:
     if os.path.exists(part): os.remove(part)
     r=subprocess.run([curl,'--fail','--location','--retry','3','--connect-timeout','20','--output',part,url],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=300)
     if r.returncode!=0: raise RuntimeError('Linux TLS voice download failed: '+(r.stderr or r.stdout)[-900:])
     if not os.path.exists(part) or os.path.getsize(part)<min_size: raise RuntimeError('Downloaded voice file is incomplete')
     os.replace(part,dest)
    finally:
     if os.path.exists(part):
      try: os.remove(part)
      except: pass
  else:
   cmd=[sys.executable,'-m','piper.download_voices','--data-dir',VOICE_DIR,voice]
   r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=300)
   if r.returncode!=0: raise RuntimeError((r.stderr or r.stdout or 'Voice download failed')[-1200:])
 if not (os.path.exists(model) and os.path.exists(config)): raise RuntimeError('Download completed but the .onnx/.onnx.json voice files were not found')
 return model,config

@app.post('/api/tts')
def tts_audio(t:TTSIn):
 text=t.text.strip()
 if not text: raise HTTPException(400,'No text to speak')
 if len(text)>2500: text=text[:2500]
 vals,voice=_selected_voice(); rate=float(vals.get('tts_rate','1.0') or 1.0)
 out=os.path.join(tempfile.gettempdir(),'family_calendar_tts_'+uuid.uuid4().hex+'.wav')
 try:
  _synthesize_piper(text,voice,out,rate)
  return FileResponse(out,media_type='audio/wav',filename='assistant.wav')
 except Exception as e: raise HTTPException(503,'Neural voice generation failed: '+str(e))

@app.get('/api/tts/status')
def tts_status():
 vals,voice=_selected_voice(); model,config=_voice_paths(voice)
 installed=_piper_available(); ready=os.path.exists(model) and os.path.exists(config)
 result={'engine':vals.get('tts_engine','piper'),'piper_python':installed,'voice':voice,'model_ready':ready,'voice_dir':VOICE_DIR,'engine_status':'Ready' if installed else 'Not installed','voice_status':'Ready' if ready else 'Missing','audio_test':'Not tested'}
 if installed and ready:
  test=os.path.join(tempfile.gettempdir(),'family_calendar_voice_health.wav')
  try:
   _synthesize_piper('Voice system ready.',voice,test,1.0); result['audio_test']='Passed'
  except Exception as e: result['audio_test']='Failed'; result['error']=str(e)
  finally:
   try: os.remove(test)
   except: pass
 return result

@app.post('/api/tts/repair')
def tts_repair():
 vals,voice=_selected_voice()
 try:
  if not _piper_available():
   r=subprocess.run([sys.executable,'-m','pip','install','--upgrade','piper-tts>=1.3.0'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=300)
   if r.returncode!=0: raise RuntimeError('Piper install failed: '+(r.stderr or r.stdout)[-1000:])
  _download_voice(voice)
  test=os.path.join(tempfile.gettempdir(),'family_calendar_voice_repair.wav')
  _synthesize_piper('Family Calendar Hub neural voice is ready.',voice,test,float(vals.get('tts_rate','1.0') or 1.0))
  size=os.path.getsize(test); os.remove(test)
  c=conn(); c.execute("insert or replace into settings(k,v) values('tts_engine','piper')"); c.commit(); c.close()
  return {'ok':True,'voice':voice,'message':'Neural voice repaired, verified, and selected.','test_bytes':size}
 except Exception as e: raise HTTPException(503,'Voice repair failed: '+str(e))

@app.get('/api/settings')
def settings():
 c=conn(); d={x['k']:x['v'] for x in c.execute('select * from settings')}; c.close(); return d
@app.put('/api/settings/{k}')
def set_setting(k:str,v:str):
 c=conn(); c.execute('insert into settings values(?,?) on conflict(k) do update set v=excluded.v',(k,v)); c.commit(); c.close(); return {'ok':True}


class RestoreIn(BaseModel): data:str; filename:str='backup.fcalbackup'

@app.get('/api/backups')
def list_backups():
 out=[]
 for fn in sorted(os.listdir(BACKUPS),reverse=True):
  if not fn.endswith('.fcalbackup'): continue
  path=os.path.join(BACKUPS,fn); ok,meta=validate_backup(path)
  out.append({'name':fn,'size':os.path.getsize(path),'modified':datetime.fromtimestamp(os.path.getmtime(path)).isoformat(),'valid':ok,'kind':meta.get('kind','') if ok else '','app_version':meta.get('app_version','') if ok else ''})
 return out

@app.post('/api/backups')
def backup_now():
 p=create_backup('manual'); return {'ok':True,'name':os.path.basename(p)}

@app.get('/api/backups/{name}')
def download_backup(name:str):
 safe=os.path.basename(name); path=os.path.join(BACKUPS,safe)
 if not os.path.isfile(path): raise HTTPException(404,'Backup not found')
 return FileResponse(path,filename=safe,media_type='application/octet-stream')

@app.delete('/api/backups/{name}')
def delete_backup(name:str):
 safe=os.path.basename(name); path=os.path.join(BACKUPS,safe)
 if not os.path.isfile(path): raise HTTPException(404,'Backup not found')
 os.remove(path); return {'ok':True}

@app.post('/api/restore')
def restore_backup(r:RestoreIn):
 try: raw=base64.b64decode(r.data.split(',',1)[-1],validate=True)
 except: raise HTTPException(400,'Invalid backup upload')
 with tempfile.NamedTemporaryFile(suffix='.fcalbackup',delete=False) as f: f.write(raw); up=f.name
 try:
  ok,meta=validate_backup(up)
  if not ok: raise HTTPException(400,'Backup validation failed: '+str(meta))
  create_backup('pre_restore')
  with zipfile.ZipFile(up) as z:
   with tempfile.NamedTemporaryFile(suffix='.db',delete=False) as d: d.write(z.read('family_calendar.db')); restored=d.name
  try:
   src=sqlite3.connect(restored); dst=sqlite3.connect(DB); src.backup(dst); dst.close(); src.close()
  finally: os.unlink(restored)
  init(); return {'ok':True,'message':'Restore complete','created_at':meta.get('created_at')}
 finally:
  try: os.unlink(up)
  except: pass

@app.get('/api/weather')
def weather(location:Optional[str]=None):
 loc=(location or '').strip()
 if not loc:
  c=conn(); z=c.execute("select v from settings where k='weather_location'").fetchone(); c.close(); loc=z['v'] if z else 'Ridgecrest, CA'
 try:
  q=urllib.parse.urlencode({'name':loc,'count':1,'language':'en','format':'json'})
  with urllib.request.urlopen('https://geocoding-api.open-meteo.com/v1/search?'+q,timeout=7) as r: geo=json.load(r)
  if not geo.get('results'): raise ValueError('Location not found')
  g=geo['results'][0]; params={'latitude':g['latitude'],'longitude':g['longitude'],'current':'temperature_2m,weather_code','daily':'weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max','temperature_unit':'fahrenheit','timezone':'auto','forecast_days':7}
  with urllib.request.urlopen('https://api.open-meteo.com/v1/forecast?'+urllib.parse.urlencode(params),timeout=7) as r: w=json.load(r)
  return {'location':f"{g.get('name','')}{', '+g.get('admin1','') if g.get('admin1') else ''}",'current':w.get('current',{}),'daily':w.get('daily',{})}
 except Exception as ex: raise HTTPException(503,'Weather unavailable: '+str(ex))

@app.get('/api/holidays')
def holidays(year:int):
 return holiday_rows(year)

@app.get('/api/health')
def health():
 try:
  c=conn(); c.execute('select 1').fetchone(); c.close()
  return {'ok':True,'version':APP_VERSION,'database':DB,'data_root':DATA_ROOT}
 except Exception as e: raise HTTPException(503,'Database health check failed: '+str(e))

@app.get('/api/system/network')
def network_access():
 ip=''
 try:
  sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); sock.connect(('8.8.8.8',80)); ip=sock.getsockname()[0]; sock.close()
 except Exception:
  try: ip=socket.gethostbyname(socket.gethostname())
  except Exception: ip=''
 return {'bind':'0.0.0.0','port':8090,'lan_ip':ip,'lan_url':f'http://{ip}:8090' if ip and not ip.startswith('127.') else ''}

@app.get('/assets/logo.png')
def logo_png(): return FileResponse(os.path.join(BASE,'assets','family_calendar_hub_logo.png'),media_type='image/png')
@app.get('/favicon.ico')
def favicon(): return FileResponse(os.path.join(BASE,'assets','family_calendar_hub.ico'),media_type='image/x-icon')
@app.get('/assets/icon.png')
def icon_png(): return FileResponse(os.path.join(BASE,'assets','family_calendar_hub_icon.png'),media_type='image/png')

HTML=r'''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no"><title>Family Calendar Hub</title><link rel="icon" href="/favicon.ico"><style>
*{box-sizing:border-box}body{margin:0;font-family:Inter,Segoe UI,Arial;background:#f6f8fb;color:#263244}button{border:0;border-radius:14px;padding:13px 17px;font-size:15px;font-weight:750;cursor:pointer;touch-action:manipulation}.app{display:grid;grid-template-columns:92px 1fr;min-height:100vh}.nav{background:#fff;border-right:1px solid #e8edf3;padding:14px 8px;display:flex;flex-direction:column;gap:8px;position:sticky;top:0;height:100vh}.logo{font-size:29px;text-align:center;margin:6px}.nav button{background:transparent;padding:12px 4px;font-size:12px;color:#64748b}.nav button b{display:block;font-size:22px;margin-bottom:4px}.nav button.active{background:#e9f7f6;color:#087f78}.main{min-width:0}.top{height:72px;background:white;display:flex;align-items:center;padding:0 22px;gap:15px;border-bottom:1px solid #e9edf2;position:sticky;top:0;z-index:5}.brand{font-size:21px;font-weight:850}.sub{font-size:12px;color:#8793a3}.spacer{flex:1}.primary{background:#16a39a;color:white}.soft{background:#edf2f7;color:#334155}.danger{background:#fee2e2;color:#991b1b}.people{display:flex;gap:20px;padding:14px 24px;background:#fff;overflow:auto;border-bottom:1px solid #edf0f4}.profile{min-width:66px;background:transparent;padding:2px;text-align:center;color:#475569}.avatar{width:48px;height:48px;border-radius:50%;display:grid;place-items:center;margin:auto;border:3px solid var(--c);background:color-mix(in srgb,var(--c) 18%,white);font-size:19px;font-weight:900;overflow:hidden}.avatar img{width:100%;height:100%;object-fit:cover}.profile.off{opacity:.3}.profile span{font-size:12px;display:block;margin-top:4px}.content{padding:18px 24px}.toolbar{display:flex;align-items:center;gap:9px;margin-bottom:12px}.toolbar h2{min-width:230px}.grid{display:grid;grid-template-columns:repeat(7,1fr);gap:7px}.dow{text-align:center;font-weight:800;color:#7b8797;padding:6px}.day{background:white;border-radius:12px;min-height:145px;padding:8px;border:1px solid #edf0f4;cursor:pointer}.day.today{outline:3px solid #23aaa2}.num{font-size:16px;font-weight:850;margin-bottom:6px}.event{padding:7px 8px;border-radius:7px;margin:4px 0;font-size:12px;font-weight:800;overflow:hidden;color:#344054}.event small{font-weight:600;opacity:.72}.event.multi{background:var(--multi)!important;border-left:0!important;box-shadow:inset 0 0 0 1px #ffffff88}.eventPeople{display:flex;gap:3px;margin-top:4px}.eventDot{width:8px;height:8px;border-radius:50%;border:1px solid #fff}.dayHead{display:flex;justify-content:space-between;align-items:center}.holiday{font-size:9px;font-weight:800;color:#a14c66;line-height:1.1;margin:2px 0 5px}.clockWeather{display:flex;align-items:center;gap:12px}.clock{font-size:20px;font-weight:900;min-width:90px;text-align:right}.weatherNow{background:#eef8fb;border-radius:14px;padding:8px 12px;font-weight:800}.forecast{display:grid;grid-template-columns:repeat(7,1fr);gap:10px}.forecastDay{background:#f7f9fc;border-radius:14px;padding:14px;text-align:center}.forecastDay b{display:block;margin-bottom:8px}.forecastIcon{font-size:30px}.weatherLocation{color:#7b8797;margin-bottom:14px}.panel{display:none}.panel.active{display:block}.settingsGrid{display:grid;grid-template-columns:minmax(300px,1fr) minmax(360px,1.5fr);gap:18px}.box{background:white;border:1px solid #e8edf3;border-radius:18px;padding:20px;margin-bottom:16px}.box h2,.box h3{margin-top:0}.userrow,.sourcerow{display:flex;align-items:center;gap:12px;padding:12px;border-bottom:1px solid #eef1f5}.userrow:last-child,.sourcerow:last-child{border:0}.userrow .avatar{margin:0}.meta{flex:1}.meta small{color:#7b8797}.palette{display:flex;gap:9px;flex-wrap:wrap}.swatch{width:38px;height:38px;border-radius:50%;border:3px solid white;outline:1px solid #ccd5df}.swatch.sel{outline:4px solid #263244}.modal{display:none;position:fixed;inset:0;background:#0007;z-index:30;align-items:center;justify-content:center;padding:18px}.modal.show{display:flex}.card{background:white;width:min(680px,100%);max-height:94vh;overflow:auto;border-radius:22px;padding:24px}.row{display:grid;grid-template-columns:1fr 1fr;gap:12px}label{display:block;font-weight:750;margin:11px 0 5px}input,textarea,select{width:100%;padding:13px;border:1px solid #ccd5df;border-radius:11px;font-size:16px}textarea{min-height:75px}.checks{display:flex;flex-wrap:wrap;gap:7px}.personCheck{padding:9px;border-radius:10px;background:#f0f3f7}.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:18px}.alert{display:none;position:fixed;right:18px;bottom:18px;z-index:40;background:#263244;color:white;border-radius:18px;padding:20px;width:min(430px,calc(100% - 36px));box-shadow:0 12px 35px #0005}.alert.show{display:block}.status{padding:4px 8px;border-radius:999px;background:#edf2f7;font-size:11px}.connection-note{background:#fff8dc;border-radius:10px;padding:10px;font-size:13px;color:#735c0f}.toggle{width:auto}.askAI{background:linear-gradient(135deg,#d8f6f2,#e9ddff);color:#334155;border:1px solid #c9dce8}.askAI.listening{animation:pulse 1s infinite;background:linear-gradient(135deg,#ffe0eb,#fff0c7)}@keyframes pulse{50%{transform:scale(1.04);box-shadow:0 0 0 9px #16a39a22}} .brandLogo{width:56px;height:56px;object-fit:contain;display:block;margin:auto} @media(max-width:800px){.app{grid-template-columns:1fr}.nav{height:auto;position:fixed;z-index:20;bottom:0;top:auto;width:100%;flex-direction:row;justify-content:space-around;border-top:1px solid #ddd;padding:5px}.nav .logo{display:none}.nav button{flex:1;padding:7px 2px}.nav button b{font-size:18px}.main{padding-bottom:72px}.top{height:auto;padding:10px 12px}.sub{display:none}.content,.people{padding-left:9px;padding-right:9px}.grid{gap:3px}.day{min-height:105px;padding:4px}.event{font-size:10px;padding:4px}.toolbar h2{font-size:18px;min-width:0}.row,.settingsGrid{grid-template-columns:1fr}.dow{font-size:10px}.people{gap:10px}.profile{min-width:58px}.avatar{width:43px;height:43px}}
</style></head><body><div class="app"><aside class="nav"><div class="logo"><img src="/assets/icon.png" alt="Family Calendar Hub" class="brandLogo"></div><button class="active" data-tab="calendar" onclick="tab('calendar',this)"><b>🏠</b>Home</button><button data-tab="calendar" onclick="tab('calendar',this)"><b>📅</b>Calendar</button><button data-tab="users" onclick="tab('users',this)"><b>👥</b>Users</button><button data-tab="settings" onclick="tab('settings',this)"><b>⚙️</b>Settings</button></aside><section class="main"><header class="top"><div><div class="brand">Family Calendar Hub</div><div class="sub" id="todayText"></div></div><div class="spacer"></div><div class="clockWeather"><div class="clock" id="liveClock"></div><div class="weatherNow" id="weatherNow">Weather --</div></div><button class="soft" onclick="openWeather()">🌦️ Weather</button><button class="askAI" id="askAiBtn" onclick="askAI()">🎙️ Ask AI</button><button class="soft" id="muteBtn" onclick="toggleMute()">🔊</button><button class="primary" onclick="newEvent()">＋ Add Event</button></header><div class="people" id="people"></div>
<div id="calendar" class="panel active content"><div class="toolbar"><button class="soft" onclick="move(-1)">‹</button><h2 id="monthTitle"></h2><button class="soft" onclick="move(1)">›</button><button class="soft" onclick="goToday()">Today</button></div><div class="grid" id="cal"></div></div>
<div id="users" class="panel content"><div class="box"><div style="display:flex;align-items:center"><div><h2>Family Members</h2><div class="sub">Photos, avatars, roles and calendar colors</div></div><div class="spacer"></div><button class="primary" onclick="personForm()">＋ Add Person</button></div><div id="userList"></div></div></div>
<div id="settings" class="panel content"><div class="settingsGrid"><div><div class="box"><h2>Alerts & Sound</h2><label><input class="toggle" type="checkbox" id="setMute"> Mute audible alerts</label><label><input class="toggle" type="checkbox" id="spoken"> Speak appointment name</label><label>Volume <span id="volLabel"></span></label><input type="range" min="0" max="1" step=".05" id="volume"><label><input class="toggle" type="checkbox" id="quietEnabled"> Quiet hours</label><div class="row"><div><label>From</label><input type="time" id="quietStart"></div><div><label>Until</label><input type="time" id="quietEnd"></div></div><button class="primary" style="margin-top:14px" onclick="saveSettings()">Save Alert Settings</button></div><div class="box"><h2>Voice Assistant</h2><div class="sub">Choose the voice used for Ask AI. Piper neural voices run locally and sound more natural than the basic browser voice.</div><label>Voice engine</label><select id="ttsEngine"><option value="piper">Piper Neural (local, recommended)</option><option value="browser">Browser / system voice</option></select><label>AI voice</label><select id="ttsVoice"><option value="en_US-lessac-medium">Lessac — US English</option><option value="en_US-amy-medium">Amy — US English</option><option value="en_US-ryan-medium">Ryan — US English</option><option value="en_GB-alan-medium">Alan — UK English</option></select><label>Speaking speed <span id="ttsRateLabel"></span></label><input type="range" min="0.75" max="1.25" step="0.05" id="ttsRate"><div class="actions"><button class="soft" onclick="testVoice()">▶ Test Voice</button><button class="soft" onclick="repairVoice()">🛠 Repair / Download Voice</button><button class="primary" onclick="saveVoiceSettings()">Save Voice</button></div><div class="connection-note" id="ttsHealth" style="margin-top:10px">Voice health not checked yet.</div><div class="sub" id="ttsStatus" style="margin-top:10px"></div></div><div class="box"><h2>Weather & Holidays</h2><label>Weather location</label><input id="weatherLocation" placeholder="City, State"><label><input class="toggle" type="checkbox" id="showHolidays"> Show U.S. holidays on calendar</label><button class="primary" style="margin-top:14px" onclick="saveDisplaySettings()">Save Display Settings</button></div></div><div><div class="box"><div style="display:flex;align-items:center"><div><h2>Calendar Connections</h2><div class="sub">Each connection belongs to a specific family member.</div></div><div class="spacer"></div><button class="primary" onclick="sourceForm()">＋ Add Connection</button></div><div class="connection-note">Apple iCloud supports private CalDAV sync using an Apple app-specific password. Apple Public Calendar Link uses an ICS/webcal URL and is read-only. Google and Microsoft require OAuth credentials for live sync. Connections remain separate per person.</div><div id="sourceList"></div></div><div class="box"><h2>Local AI</h2><div class="sub">Private on-device AI powered by Ollama.</div><div id="aiStatus" class="connection-note" style="margin-top:12px">Checking Ollama…</div><label>Local model</label><select id="aiModel"></select><div class="actions"><button class="primary" onclick="saveAIModel()">Use Selected Model</button><button class="soft" onclick="loadAI()">↻ Detect Models</button><button class="soft" id="pullLlama" onclick="pullRequiredModel()">Install llama3.2:3b</button></div><div class="sub" style="margin-top:10px">The installer automatically installs Ollama when missing and ensures llama3.2:3b is present. Other locally installed Ollama models appear here automatically.</div></div><div class="box"><h2>Backup & Restore</h2><div class="sub">Protect family profiles, photos, events, connections and settings.</div><label><input class="toggle" type="checkbox" id="autoBackup"> Automatic daily backups</label><label>Backups to keep</label><select id="backupRetention"><option>7</option><option>14</option><option>30</option></select><div class="actions"><button class="primary" onclick="backupNow()">Back Up Now</button><button class="soft" onclick="$('restoreFile').click()">Restore Backup</button><input id="restoreFile" type="file" accept=".fcalbackup" style="display:none"></div><div class="connection-note">A safety backup is created automatically before every restore. Uploaded backups are validated before your current calendar is changed.</div><div id="backupList" style="margin-top:12px"></div></div></div></div></div>
</section></div>
<div class="modal" id="eventModal"><div class="card"><h2 id="formTitle">Add Event</h2><input type="hidden" id="eid"><label>Event</label><input id="title"><div class="row"><div><label>Starts</label><input type="datetime-local" id="start"></div><div><label>Ends</label><input type="datetime-local" id="end"></div></div><label>Location</label><input id="location"><label>Family members</label><div class="checks" id="checks"></div><div class="row"><div><label>Repeat</label><select id="recurrence"><option value="">Does not repeat</option><option value="daily">Daily</option><option value="weekly">Weekly</option><option value="monthly">Monthly</option><option value="yearly">Yearly</option></select></div><div><label>Reminders</label><label><input class="toggle" type="checkbox" id="r60" checked> 1 hour before</label><label><input class="toggle" type="checkbox" id="r15" checked> 15 minutes before</label></div></div><label>Notes</label><textarea id="notes"></textarea><div class="actions"><button class="primary" onclick="saveEvent()">Save</button><button class="soft" onclick="closeM('eventModal')">Cancel</button><button class="danger" id="deleteBtn" onclick="deleteEvent()">Delete</button></div></div></div>
<div class="modal" id="personModal"><div class="card"><h2 id="personTitle">Family Member</h2><input type="hidden" id="pid"><label>Name</label><input id="pname"><label>Role</label><select id="prole"><option value="admin">Parent / Admin</option><option value="member">Family Member</option><option value="child">Child</option></select><label>Calendar color</label><div class="palette" id="palette"></div><input type="hidden" id="pcolor"><label>Photo / Avatar</label><input type="file" id="pfile" accept="image/*"><div class="sub">Optional. Stored locally in this calendar installation.</div><input type="hidden" id="pavatar"><div class="actions"><button class="primary" onclick="savePerson()">Save Person</button><button class="soft" onclick="closeM('personModal')">Cancel</button><button class="danger" id="personDelete" onclick="deletePerson()">Delete</button></div></div></div>
<div class="modal" id="sourceModal"><div class="card"><h2>Calendar Connection</h2><input type="hidden" id="sid"><label>Family member</label><select id="sourcePerson"></select><label>Connection name</label><input id="sourceName" placeholder="Mom's Personal Google"><label>Provider</label><select id="provider"><option value="apple_caldav">Apple iCloud — Private CalDAV</option><option value="apple_ics">Apple Calendar Link — Read Only</option><option value="google">Google Calendar</option><option value="microsoft">Microsoft Outlook / 365</option><option value="ics">Generic ICS / iCal subscription</option><option value="local">Local calendar</option></select><div id="appleFields"><label>Apple Account email (private CalDAV)</label><input id="sourceUsername" placeholder="name@icloud.com"><label>App-specific password (private CalDAV)</label><input id="sourcePassword" type="password" placeholder="Leave blank to keep saved password"><label>CalDAV server</label><input id="externalId" placeholder="https://caldav.icloud.com"><label>Calendar name or URL (optional)</label><input id="calendarUrl" placeholder="Leave blank to use the first discovered calendar"><div class="connection-note" style="margin-top:10px">For Apple Calendar Link, paste the public webcal/ICS URL in the CalDAV server / URL field. Public links are read-only.</div></div><label><input class="toggle" type="checkbox" id="syncEnabled" checked> Synchronization enabled</label><div class="actions"><button class="primary" onclick="saveSource()">Save Connection</button><button class="soft" onclick="closeM('sourceModal')">Cancel</button></div></div></div>
<div class="modal" id="weatherModal"><div class="card"><div style="display:flex;align-items:center"><div><h2>7-Day Weather</h2><div class="weatherLocation" id="forecastLocation"></div></div><div class="spacer"></div><button class="soft" onclick="closeM('weatherModal')">Close</button></div><div class="forecast" id="forecast"></div></div></div><div class="alert" id="alert"><h2 id="alertTitle"></h2><div id="alertText"></div><div class="actions"><button class="primary" onclick="dismissAlert()">Dismiss</button><button class="soft" onclick="snooze(5)">Snooze 5m</button><button class="soft" onclick="snooze(15)">15m</button><button class="soft" onclick="silenceHour()">Silence 1h</button></div></div>
<script>
let P=[],E=[],S=[],H=[],W=null,shown=new Set(),cursor=new Date(),muted=false,settings={},silencedUntil=0,alerted=new Set(),currentAudio=null;const $=id=>document.getElementById(id),COLORS=['#f59ab8','#74a7f7','#f2bd63','#79cf9a','#b28ae8','#ef8585','#72c8c1','#9bbf68','#e89bc9','#7d9de8','#f29c72','#8dc7e8'];const iso=d=>{let z=new Date(d-d.getTimezoneOffset()*60000);return z.toISOString().slice(0,16)};async function api(u,o){let r=await fetch(u,o);if(!r.ok)throw Error(await r.text());return r.json()}
async function load(){P=await api('/api/people');S=await api('/api/sources');P.forEach(p=>shown.add(p.id));settings=await api('/api/settings');muted=settings.muted==='1';muteUI();await Promise.all([loadEvents(),loadHolidays(),loadWeather()]);renderPeople();render();renderUsers();renderSources();loadSettings();loadBackups();loadAI();startClock()}
function avatar(p){return p.avatar?`<img src="${p.avatar}">`:(p.name||'?').split(/\s+/).map(x=>x[0]).join('').slice(0,2).toUpperCase()}
function renderPeople(){$('people').innerHTML=P.map(p=>`<button class="profile ${shown.has(p.id)?'':'off'}" style="--c:${p.color}" onclick="filterP('${p.id}')"><div class="avatar">${avatar(p)}</div><span>${p.name}</span></button>`).join('')}
function filterP(id){shown.has(id)?shown.delete(id):shown.add(id);renderPeople();render()}function colors(e){return e.person_ids.map(id=>P.find(x=>x.id===id)?.color).filter(Boolean)}function eventStyle(e){let c=colors(e);if(!c.length)c=['#9aa6b2'];if(c.length===1)return `background:color-mix(in srgb,${c[0]} 58%,white);border-left:6px solid ${c[0]};color:#24384a`;;let step=100/c.length,stops=c.map((x,i)=>`color-mix(in srgb,${x} 68%,white) ${i*step}% ${(i+1)*step}%`).join(',');return `--multi:linear-gradient(90deg,${stops})`}function eventDots(e){return `<div class="eventPeople">${colors(e).map(c=>`<i class="eventDot" style="background:${c}"></i>`).join('')}</div>`}
async function loadHolidays(){H=settings.show_holidays==='0'?[]:await api('/api/holidays?year='+cursor.getFullYear())}function holidayFor(d){let k=[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');return H.filter(x=>x.date===k)}function wxIcon(c){if(c===0)return '☀️';if([1,2].includes(c))return '🌤️';if(c===3)return '☁️';if([45,48].includes(c))return '🌫️';if(c>=51&&c<=67)return '🌧️';if(c>=71&&c<=77)return '🌨️';if(c>=80&&c<=82)return '🌦️';if(c>=95)return '⛈️';return '🌤️'}async function loadWeather(){try{W=await api('/api/weather?location='+encodeURIComponent(settings.weather_location||''));let c=W.current||{};$('weatherNow').textContent=wxIcon(c.weather_code)+' '+Math.round(c.temperature_2m||0)+'°'}catch(e){$('weatherNow').textContent='Weather unavailable'}}function openWeather(){if(!W)return loadWeather();$('forecastLocation').textContent=W.location||'';let d=W.daily||{};$('forecast').innerHTML=(d.time||[]).map((x,i)=>`<div class="forecastDay"><b>${new Date(x+'T12:00').toLocaleDateString([],{weekday:'short'})}</b><div class="forecastIcon">${wxIcon(d.weather_code[i])}</div><strong>${Math.round(d.temperature_2m_max[i])}°</strong> / ${Math.round(d.temperature_2m_min[i])}°<br><small>💧 ${d.precipitation_probability_max[i]||0}%</small></div>`).join('');$('weatherModal').classList.add('show')}function startClock(){let f=()=>{$('liveClock').textContent=new Date().toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})};f();setInterval(f,1000)}async function loadEvents(){let a=new Date(cursor.getFullYear(),cursor.getMonth(),1),b=new Date(cursor.getFullYear(),cursor.getMonth()+1,1);E=await api('/api/events?start='+encodeURIComponent(a.toISOString())+'&end='+encodeURIComponent(b.toISOString()))}
function eventDate(e){if(e.all_day){let a=(e.start||'').slice(0,10).split('-').map(Number);return new Date(a[0],a[1]-1,a[2],12,0,0)}return new Date(e.start)}function eventTime(e){return e.all_day?'All day':eventDate(e).toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})}function render(){let y=cursor.getFullYear(),m=cursor.getMonth();$('monthTitle').textContent=cursor.toLocaleString([],{month:'long',year:'numeric'});$('todayText').textContent=new Date().toLocaleString([],{weekday:'long',month:'long',day:'numeric'});let first=new Date(y,m,1),start=new Date(y,m,1-first.getDay());let h=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(x=>`<div class="dow">${x}</div>`).join('');for(let i=0;i<42;i++){let d=new Date(start);d.setDate(start.getDate()+i);let key=d.toDateString(),today=key===new Date().toDateString();let ev=E.filter(e=>eventDate(e).toDateString()===key&&e.person_ids.some(p=>shown.has(p)));let hol=holidayFor(d);h+=`<div class="day ${today?'today':''}" onclick="dayAdd('${iso(new Date(d.setHours(9,0,0,0)))}')"><div class="dayHead"><div class="num">${d.getDate()}</div>${today?'<small>Today</small>':''}</div>${hol.map(x=>`<div class="holiday">🇺🇸 ${x.name}</div>`).join('')}${ev.map(e=>`<div class="event ${colors(e).length>1?'multi':''}" style="${eventStyle(e)}" onclick="event.stopPropagation();edit('${e.id}')">${eventTime(e)} ${e.title}<br><small>${e.location||''}</small>${eventDots(e)}</div>`).join('')}</div>`}$('cal').innerHTML=h}
function tab(id,b){document.querySelectorAll('.panel').forEach(x=>x.classList.remove('active'));$(id).classList.add('active');document.querySelectorAll('.nav button').forEach(x=>x.classList.remove('active'));b.classList.add('active')}async function move(n){cursor.setMonth(cursor.getMonth()+n);await Promise.all([loadEvents(),loadHolidays()]);render()}async function goToday(){cursor=new Date();await Promise.all([loadEvents(),loadHolidays()]);render()}
function dayAdd(v){newEvent();$('start').value=v;let d=new Date(v);d.setHours(d.getHours()+1);$('end').value=iso(d)}function newEvent(){['eid','title','location','notes'].forEach(x=>$(x).value='');let d=new Date();d.setMinutes(Math.ceil(d.getMinutes()/15)*15,0,0);$('start').value=iso(d);d.setHours(d.getHours()+1);$('end').value=iso(d);$('r60').checked=$('r15').checked=true;$('recurrence').value='';$('checks').innerHTML=P.map(p=>`<label class="personCheck" style="border-left:5px solid ${p.color}"><input class="toggle" type="checkbox" value="${p.id}"> ${p.name}</label>`).join('');$('deleteBtn').style.display='none';$('formTitle').textContent='Add Event';$('eventModal').classList.add('show')}
function edit(id){let e=E.find(x=>x.id===id);newEvent();$('eid').value=id;$('title').value=e.title;$('start').value=iso(new Date(e.start));$('end').value=iso(new Date(e.end));$('location').value=e.location;$('notes').value=e.notes;$('r60').checked=!!e.remind_60;$('r15').checked=!!e.remind_15;$('recurrence').value=e.recurrence||'';document.querySelectorAll('#checks input').forEach(x=>x.checked=e.person_ids.includes(x.value));$('deleteBtn').style.display='block';$('formTitle').textContent='Edit Event'}function closeM(id){$(id).classList.remove('show')}
async function saveEvent(){if(!$('title').value.trim())return alert('Enter an event name');let body={title:$('title').value,start:new Date($('start').value).toISOString(),end:new Date($('end').value).toISOString(),location:$('location').value,notes:$('notes').value,person_ids:[...document.querySelectorAll('#checks input:checked')].map(x=>x.value),remind_60:$('r60').checked,remind_15:$('r15').checked,recurrence:$('recurrence').value};let id=$('eid').value;await api(id?'/api/events/'+id:'/api/events',{method:id?'PUT':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});closeM('eventModal');await loadEvents();render()}async function deleteEvent(){let id=$('eid').value;if(id&&confirm('Delete this event?')){await api('/api/events/'+id,{method:'DELETE'});closeM('eventModal');await loadEvents();render()}}
function renderUsers(){$('userList').innerHTML=P.map(p=>`<div class="userrow"><div class="avatar" style="--c:${p.color}">${avatar(p)}</div><div class="meta"><b>${p.name}</b><br><small>${p.role}</small></div><button class="soft" onclick="personForm('${p.id}')">Edit</button></div>`).join('')}
function personForm(id=''){let p=P.find(x=>x.id===id);$('pid').value=id;$('pname').value=p?.name||'';$('prole').value=p?.role||'member';$('pcolor').value=p?.color||COLORS[P.length%COLORS.length];$('pavatar').value=p?.avatar||'';$('personDelete').style.display=id?'block':'none';drawPalette();$('personModal').classList.add('show')}function drawPalette(){$('palette').innerHTML=COLORS.map(c=>`<button class="swatch ${$('pcolor').value===c?'sel':''}" style="background:${c}" onclick="event.preventDefault();$('pcolor').value='${c}';drawPalette()"></button>`).join('')}
$('pfile').addEventListener('change',e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{$('pavatar').value=r.result};r.readAsDataURL(f)});async function savePerson(){let body={name:$('pname').value.trim(),role:$('prole').value,color:$('pcolor').value,avatar:$('pavatar').value};if(!body.name)return alert('Enter a name');let id=$('pid').value;await api(id?'/api/people/'+id:'/api/people',{method:id?'PUT':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});closeM('personModal');await load()}async function deletePerson(){let id=$('pid').value;if(id&&confirm('Delete this family member? Their assignments and connections will also be removed.')){await api('/api/people/'+id,{method:'DELETE'});closeM('personModal');await load()}}
function renderSources(){let valid=new Set(P.map(p=>p.id));S=S.filter(s=>valid.has(s.person_id));$('sourceList').innerHTML=S.map(s=>{let p=P.find(x=>x.id===s.person_id);return `<div class="sourcerow"><div class="avatar" style="--c:${p?.color||'#aaa'}">${p?avatar(p):'?'}</div><div class="meta"><b>${s.name}</b><br><small>${p?.name||'Unknown'} • ${s.provider}</small></div><span class="status">${s.sync_enabled?'Auto-sync: 5 min':'Paused'} • ${s.connection_status||'local'}${s.last_sync?' • Last: '+new Date(s.last_sync).toLocaleTimeString([],{hour:'numeric',minute:'2-digit'}):''}</span>${['apple_caldav','apple_ics'].includes(s.provider)?`<button class="soft" onclick="syncSource('${s.id}')">↻ Sync</button>`:''}<button class="soft" onclick="sourceForm('${s.id}')">Edit</button></div>`}).join('')}
function sourceForm(id=''){let s=S.find(x=>x.id===id);$('sid').value=id;$('sourcePerson').innerHTML=P.map(p=>`<option value="${p.id}">${p.name}</option>`).join('');$('sourcePerson').value=s?.person_id||P[0]?.id||'';$('sourceName').value=s?.name||'';$('provider').value=s?.provider||'apple_caldav';$('externalId').value=s?.external_id||($('provider').value==='apple_caldav'?'https://caldav.icloud.com':'');$('sourceUsername').value=s?.username||'';$('sourcePassword').value='';$('calendarUrl').value=s?.calendar_url||'';$('syncEnabled').checked=s?!!s.sync_enabled:true;$('sourceModal').classList.add('show')}async function saveSource(){let body={person_id:$('sourcePerson').value,name:$('sourceName').value.trim(),provider:$('provider').value,external_id:$('externalId').value,sync_enabled:$('syncEnabled').checked,username:$('sourceUsername').value.trim(),password:$('sourcePassword').value,calendar_url:$('calendarUrl').value.trim()};if(!body.name)return alert('Enter a connection name');let id=$('sid').value;let r=await api(id?'/api/sources/'+id:'/api/sources',{method:id?'PUT':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});closeM('sourceModal');S=await api('/api/sources');renderSources()}async function syncSource(id){try{let r=await api('/api/sources/'+id+'/sync',{method:'POST'});alert(`Sync complete. ${r.count} calendar events processed.`);await load()}catch(e){alert(e.message||e)}}
async function speakAI(text){if(settings.tts_engine!=='browser'){try{let r=await fetch('/api/tts',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:text})});if(!r.ok)throw new Error(await r.text());let blob=await r.blob(),url=URL.createObjectURL(blob);if(currentAudio){try{currentAudio.pause()}catch(_){}}let a=new Audio(url);currentAudio=a;a.volume=parseFloat(settings.volume||'.85');a.onended=()=>{URL.revokeObjectURL(url);if(currentAudio===a)currentAudio=null};await a.play();return}catch(e){console.error('Neural TTS failed',e);let msg='Neural voice failed. I did not fall back to the robotic system voice. Open Settings, Voice Assistant, and run Test Voice.';let el=$('ttsStatus');if(el)el.textContent='⚠️ '+msg;alert(msg);throw e}}if(!('speechSynthesis' in window)){alert('Voice playback is unavailable.');return}speechSynthesis.cancel();let u=new SpeechSynthesisUtterance(text);u.volume=parseFloat(settings.volume||'.85');u.rate=parseFloat(settings.tts_rate||'1');let wanted=settings.browser_voice||'';if(wanted){let v=speechSynthesis.getVoices().find(x=>x.name===wanted);if(v)u.voice=v}speechSynthesis.speak(u)}
async function refreshVoiceHealth(){try{let st=await api('/api/tts/status');let h=$('ttsHealth');if(h)h.textContent=`Engine: ${st.engine_status} • Voice Model: ${st.voice_status} • Audio Test: ${st.audio_test}${st.error?' • '+st.error:''}`;return st}catch(e){let h=$('ttsHealth');if(h)h.textContent='Voice health check failed: '+e.message;throw e}}
async function repairVoice(){let b=$('ttsStatus');b.textContent='Repairing neural voice and downloading the selected model…';try{let r=await api('/api/tts/repair',{method:'POST'});b.textContent='✓ '+r.message;await refreshVoiceHealth();await speakAI('Family Calendar Hub neural voice is repaired and ready.')}catch(e){b.textContent='⚠️ '+e.message;await refreshVoiceHealth().catch(()=>{})}}
async function testVoice(){let b=$('ttsStatus');b.textContent='Checking neural voice…';try{let st=await refreshVoiceHealth();if(settings.tts_engine!=='browser'&&(!st.piper_python||!st.model_ready||st.audio_test!=='Passed'))throw new Error('Neural voice is not ready. Tap Repair / Download Voice.');b.textContent='Testing '+(settings.tts_engine==='browser'?'system voice':st.voice+' neural voice')+'…';await speakAI('Hi. I am your Family Calendar Hub assistant. This is how my selected voice sounds.');b.textContent='✓ Voice test is using '+(settings.tts_engine==='browser'?'system voice':st.voice+' neural voice')+'.'}catch(e){b.textContent='⚠️ Voice test failed: '+e.message}}
async function saveVoiceSettings(){for(let [k,v] of Object.entries({tts_engine:$('ttsEngine').value,tts_voice:$('ttsVoice').value,tts_rate:$('ttsRate').value}))await api('/api/settings/'+k+'?v='+encodeURIComponent(v),{method:'PUT'});settings=await api('/api/settings');$('ttsStatus').textContent='Voice settings saved.';await refreshVoiceHealth().catch(()=>{})}
async function askAI(){let b=$('askAiBtn');let SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){alert('Voice recognition is not available in this browser. Use Chrome or Edge on the calendar display.');return}let r=new SR();r.lang='en-US';r.interimResults=false;r.maxAlternatives=1;b.classList.add('listening');b.textContent='🎙️ Listening…';r.onresult=async ev=>{let q=ev.results[0][0].transcript;b.textContent='✨ Thinking…';try{let out=await api('/api/ai/ask',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:q})});b.textContent='🔊 Speaking…';speakAI(out.answer)}catch(e){speakAI('I could not reach the local AI. Please check Local AI in Settings.')}finally{setTimeout(()=>{b.classList.remove('listening');b.textContent='🎙️ Ask AI'},900)}};r.onerror=()=>{b.classList.remove('listening');b.textContent='🎙️ Ask AI';speakAI('I did not catch that. Please try again.')};r.onend=()=>{if(b.textContent==='🎙️ Listening…'){b.classList.remove('listening');b.textContent='🎙️ Ask AI'}};r.start()}
async function loadAI(){let st=$('aiStatus'),sel=$('aiModel'),btn=$('pullLlama');st.textContent='Checking Ollama…';try{let a=await api('/api/ai/status');sel.innerHTML='';if(!a.ollama){st.textContent='⚠️ Ollama is not running or was not detected. Re-run the installer or start Ollama.';let o=document.createElement('option');o.value='llama3.2:3b';o.textContent='llama3.2:3b';sel.appendChild(o);btn.style.display='';return}st.textContent='✓ Ollama connected • '+a.models.length+' model'+(a.models.length===1?'':'s')+' detected';let models=a.models.length?a.models:['llama3.2:3b'];models.forEach(m=>{let o=document.createElement('option');o.value=m;o.textContent=m;sel.appendChild(o)});if(!models.includes(a.selected)){let o=document.createElement('option');o.value=a.selected;o.textContent=a.selected+' (selected / not installed)';sel.appendChild(o)}sel.value=a.selected;btn.style.display=a.required_installed?'none':''}catch(e){st.textContent='⚠️ Unable to check local AI: '+e.message}}async function saveAIModel(){let m=$('aiModel').value;if(!m)return;await api('/api/settings/local_ai_model?v='+encodeURIComponent(m),{method:'PUT'});settings.local_ai_model=m;alert('Local AI model saved: '+m)}async function pullRequiredModel(){let b=$('pullLlama');b.disabled=true;b.textContent='Installing llama3.2:3b…';try{await api('/api/ai/pull/llama3.2:3b',{method:'POST'});await loadAI();alert('llama3.2:3b is installed')}catch(e){alert(e.message)}finally{b.disabled=false;b.textContent='Install llama3.2:3b'}}
function loadSettings(){$('setMute').checked=settings.muted==='1';$('spoken').checked=settings.spoken_alerts!=='0';$('quietEnabled').checked=settings.quiet_enabled!=='0';$('quietStart').value=settings.quiet_start||'21:00';$('quietEnd').value=settings.quiet_end||'07:00';$('volume').value=settings.volume||'.85';$('volLabel').textContent=Math.round($('volume').value*100)+'%';$('weatherLocation').value=settings.weather_location||'Ridgecrest, CA';$('showHolidays').checked=settings.show_holidays!=='0';$('autoBackup').checked=settings.auto_backup!=='0';$('backupRetention').value=settings.backup_retention||'14';$('ttsEngine').value=settings.tts_engine||'piper';$('ttsVoice').value=settings.tts_voice||'en_US-lessac-medium';$('ttsRate').value=settings.tts_rate||'1.0';$('ttsRateLabel').textContent=(parseFloat($('ttsRate').value)).toFixed(2)+'×'}$('ttsRate').oninput=()=>{$('ttsRateLabel').textContent=parseFloat($('ttsRate').value).toFixed(2)+'×'};$('volume').oninput=()=>{$('volLabel').textContent=Math.round($('volume').value*100)+'%';$('weatherLocation').value=settings.weather_location||'Ridgecrest, CA';$('showHolidays').checked=settings.show_holidays!=='0';$('autoBackup').checked=settings.auto_backup!=='0';$('backupRetention').value=settings.backup_retention||'14';$('ttsEngine').value=settings.tts_engine||'piper';$('ttsVoice').value=settings.tts_voice||'en_US-lessac-medium';$('ttsRate').value=settings.tts_rate||'1.0';$('ttsRateLabel').textContent=(parseFloat($('ttsRate').value)).toFixed(2)+'×'};async function saveSettings(){for(let [k,v] of Object.entries({muted:$('setMute').checked?'1':'0',spoken_alerts:$('spoken').checked?'1':'0',quiet_enabled:$('quietEnabled').checked?'1':'0',quiet_start:$('quietStart').value,quiet_end:$('quietEnd').value,volume:$('volume').value,auto_backup:$('autoBackup').checked?'1':'0',backup_retention:$('backupRetention').value}))await api('/api/settings/'+k+'?v='+encodeURIComponent(v),{method:'PUT'});settings=await api('/api/settings');muted=settings.muted==='1';muteUI();alert('Settings saved')}
async function saveDisplaySettings(){for(let [k,v] of Object.entries({weather_location:$('weatherLocation').value.trim(),show_holidays:$('showHolidays').checked?'1':'0'}))await api('/api/settings/'+k+'?v='+encodeURIComponent(v),{method:'PUT'});settings=await api('/api/settings');await Promise.all([loadWeather(),loadHolidays()]);render();alert('Display settings saved')}async function toggleMute(){muted=!muted;await api('/api/settings/muted?v='+(muted?'1':'0'),{method:'PUT'});settings.muted=muted?'1':'0';muteUI()}function muteUI(){$('muteBtn').textContent=muted?'🔇':'🔊'}function quiet(){if(settings.quiet_enabled==='0')return false;let now=new Date(),cur=now.toTimeString().slice(0,5),a=settings.quiet_start||'21:00',b=settings.quiet_end||'07:00';return a>b?(cur>=a||cur<b):(cur>=a&&cur<b)}function speak(t){if(muted||Date.now()<silencedUntil||quiet()||settings.spoken_alerts==='0')return;speakAI(t).catch(e=>console.error('Reminder voice failed',e))}function notify(e,min){let key=e.id+'-'+min;if(alerted.has(key))return;alerted.add(key);$('alertTitle').textContent=e.title;$('alertText').textContent=min+' minutes away'+(e.location?' • '+e.location:'');$('alert').classList.add('show');speak(`${e.title} is in ${min} minutes`)}function dismissAlert(){$('alert').classList.remove('show');speechSynthesis.cancel();if(currentAudio){try{currentAudio.pause()}catch(_){}currentAudio=null}}function snooze(m){let t=$('alertTitle').textContent;dismissAlert();setTimeout(()=>{$('alertTitle').textContent=t;$('alertText').textContent='Snoozed reminder';$('alert').classList.add('show');speak(t+' reminder')},m*60000)}function silenceHour(){silencedUntil=Date.now()+3600000;dismissAlert()}
async function loadBackups(){try{let b=await api('/api/backups');$('backupList').innerHTML=b.length?b.map(x=>`<div class="sourcerow"><div class="meta"><b>${x.name}</b><br><small>${new Date(x.modified).toLocaleString()} • ${(x.size/1024).toFixed(1)} KB • ${x.kind||'backup'} • ${x.valid?'Verified':'Invalid'}</small></div><button class="soft" onclick="location.href='/api/backups/${encodeURIComponent(x.name)}'">Download</button><button class="danger" onclick="deleteBackup('${x.name}')">Delete</button></div>`).join(''):'<div class="sub" style="padding:12px">No backups yet.</div>'}catch(e){$('backupList').innerHTML='<div class="sub">Could not load backups.</div>'}}
async function backupNow(){let r=await api('/api/backups',{method:'POST'});await loadBackups();alert('Backup created: '+r.name)}
async function deleteBackup(n){if(confirm('Delete this backup?')){await api('/api/backups/'+encodeURIComponent(n),{method:'DELETE'});await loadBackups()}}
$('restoreFile').addEventListener('change',e=>{let f=e.target.files[0];if(!f)return;if(!confirm('Restore this backup? A safety backup of the current calendar will be created first.')){e.target.value='';return}let rd=new FileReader();rd.onload=async()=>{try{let r=await api('/api/restore',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({filename:f.name,data:rd.result})});alert(r.message+'. The calendar will reload now.');location.reload()}catch(err){alert('Restore failed: '+err.message)}finally{e.target.value=''}};rd.readAsDataURL(f)});
async function checkAlerts(){let now=Date.now();for(let e of E){let diff=(new Date(e.start)-now)/60000;if(e.remind_60&&diff>59.5&&diff<60.5)notify(e,60);if(e.remind_15&&diff>14.5&&diff<15.5)notify(e,15)}}setInterval(checkAlerts,30000);load();
</script></body></html>
'''
@app.get('/',response_class=HTMLResponse)
def home(): return HTML
